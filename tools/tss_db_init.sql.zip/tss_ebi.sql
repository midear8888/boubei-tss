-- MySQL dump 10.13  Distrib 5.5.44, for osx10.8 (i386)
--
-- Host: localhost    Database: tss
-- ------------------------------------------------------
-- Server version	5.5.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `TBL_TEMP_`
--

DROP TABLE IF EXISTS `TBL_TEMP_`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TBL_TEMP_` (
  `pk` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` bigint(20) DEFAULT NULL,
  `thread` bigint(20) DEFAULT NULL,
  `udf1` varchar(255) DEFAULT NULL,
  `udf2` varchar(255) DEFAULT NULL,
  `udf3` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pk`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TBL_TEMP_`
--

LOCK TABLES `TBL_TEMP_` WRITE;
/*!40000 ALTER TABLE `TBL_TEMP_` DISABLE KEYS */;
/*!40000 ALTER TABLE `TBL_TEMP_` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_module_def`
--

DROP TABLE IF EXISTS `cloud_module_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_module_def` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` longtext,
  `kind` varchar(255) DEFAULT NULL,
  `module` varchar(255) NOT NULL,
  `remark` longtext,
  `resource` longtext,
  `roles` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ud_module_def_domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_module_def`
--

LOCK TABLES `cloud_module_def` WRITE;
/*!40000 ALTER TABLE `cloud_module_def` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_module_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cloud_module_user`
--

DROP TABLE IF EXISTS `cloud_module_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cloud_module_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `moduleId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cloud_module_user`
--

LOCK TABLES `cloud_module_user` WRITE;
/*!40000 ALTER TABLE `cloud_module_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `cloud_module_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_article`
--

DROP TABLE IF EXISTS `cms_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_article` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `comment` longtext,
  `commentNum` int(11) NOT NULL,
  `content` longtext,
  `hitCount` int(11) DEFAULT NULL,
  `isTop` int(11) DEFAULT NULL,
  `issueDate` datetime DEFAULT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `overdueDate` datetime DEFAULT NULL,
  `pubUrl` varchar(255) DEFAULT NULL,
  `seqNo` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `channel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK935C9C00E23E43D1` (`channel_id`),
  KEY `idx_article_createTime` (`createTime`),
  KEY `idx_article_status` (`status`),
  KEY `idx_article_AUTHOR` (`author`),
  KEY `idx_article_ISSUEDATE` (`issueDate`),
  CONSTRAINT `FK935C9C00E23E43D1` FOREIGN KEY (`channel_id`) REFERENCES `cms_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_article`
--

LOCK TABLES `cms_article` WRITE;
/*!40000 ALTER TABLE `cms_article` DISABLE KEYS */;
INSERT INTO `cms_article` VALUES (1,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'Jon.King',NULL,0,' 欢迎来到它山石的世界',0,0,NULL,'它山石 BI 数据管理','2118-04-20 00:26:35',NULL,0,2,NULL,NULL,'欢迎来到它山石的世界',2);
/*!40000 ALTER TABLE `cms_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_attachment`
--

DROP TABLE IF EXISTS `cms_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_attachment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `articleId` bigint(20) DEFAULT NULL,
  `fileExt` varchar(255) DEFAULT NULL,
  `fileName` varchar(255) NOT NULL,
  `hitCount` int(11) DEFAULT NULL,
  `localPath` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `seqNo` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_attachment`
--

LOCK TABLES `cms_attachment` WRITE;
/*!40000 ALTER TABLE `cms_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `cms_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_channel`
--

DROP TABLE IF EXISTS `cms_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `docPath` varchar(255) DEFAULT NULL,
  `imagePath` varchar(255) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `overdueDate` varchar(255) DEFAULT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `seqNo` int(11) NOT NULL,
  `site_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parentId` (`parentId`,`name`),
  KEY `FKEB0F4C0DD27F8B0D` (`site_id`),
  KEY `idx_channel_name` (`name`),
  KEY `idx_channel_DECODE` (`decode`),
  CONSTRAINT `FKEB0F4C0DD27F8B0D` FOREIGN KEY (`site_id`) REFERENCES `cms_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_channel`
--

LOCK TABLES `cms_channel` WRITE;
/*!40000 ALTER TABLE `cms_channel` DISABLE KEYS */;
INSERT INTO `cms_channel` VALUES (1,'2018-04-20 00:26:35',-1,NULL,1,NULL,NULL,NULL,'0000100001',0,'doc','img',2,'我的站点','0',-1,'temp',NULL,1,1),(2,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'000010000100001',0,NULL,NULL,3,'公告栏','0',1,NULL,NULL,1,1);
/*!40000 ALTER TABLE `cms_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_permission_channel`
--

DROP TABLE IF EXISTS `cms_permission_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms_permission_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_permission_channel`
--

LOCK TABLES `cms_permission_channel` WRITE;
/*!40000 ALTER TABLE `cms_permission_channel` DISABLE KEYS */;
INSERT INTO `cms_permission_channel` VALUES (1,1,1,'1',2,-1,'全部',-1),(2,1,1,'2',2,-1,'全部',-1),(3,1,1,'3',2,-1,'全部',-1),(4,1,1,'4',2,-1,'全部',-1),(5,1,1,'5',2,-1,'全部',-1),(6,1,1,'6',2,-1,'全部',-1),(7,1,1,'7',2,-1,'全部',-1),(8,1,1,'8',2,-1,'全部',-1),(9,1,1,'9',2,-1,'全部',-1),(10,1,1,'1',2,1,'我的站点',-1),(11,1,1,'2',2,1,'我的站点',-1),(12,1,1,'3',2,1,'我的站点',-1),(13,1,1,'4',2,1,'我的站点',-1),(14,1,1,'5',2,1,'我的站点',-1),(15,1,1,'6',2,1,'我的站点',-1),(16,1,1,'7',2,1,'我的站点',-1),(17,1,1,'8',2,1,'我的站点',-1),(18,1,1,'9',2,1,'我的站点',-1),(19,1,1,'1',2,2,'公告栏',-1),(20,1,1,'2',2,2,'公告栏',-1),(21,1,1,'3',2,2,'公告栏',-1),(22,1,1,'4',2,2,'公告栏',-1),(23,1,1,'5',2,2,'公告栏',-1),(24,1,1,'6',2,2,'公告栏',-1),(25,1,1,'7',2,2,'公告栏',-1),(26,1,1,'8',2,2,'公告栏',-1),(27,1,1,'9',2,2,'公告栏',-1),(28,0,0,'1',1,1,'我的站点',-8),(29,0,0,'1',1,2,'公告栏',-8),(30,0,0,'3',1,2,'公告栏',-8),(31,0,0,'5',1,2,'公告栏',-8),(32,0,0,'4',1,2,'公告栏',-8),(33,0,0,'1',1,2,'公告栏',-10000);
/*!40000 ALTER TABLE `cms_permission_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `component_job_def`
--

DROP TABLE IF EXISTS `component_job_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `component_job_def` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `customizeInfo` longtext,
  `description` varchar(255) DEFAULT NULL,
  `disabled` int(11) NOT NULL,
  `jobClassName` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `remark` longtext,
  `timeStrategy` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `component_job_def`
--

LOCK TABLES `component_job_def` WRITE;
/*!40000 ALTER TABLE `component_job_def` DISABLE KEYS */;
INSERT INTO `component_job_def` VALUES (1,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-sync-user','4,G7','',1,'com.boubei.tss.um.syncdata.SyncUserJob','用户&组织同步','','0 0 02 * * ?'),(2,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-clean-permission','X','',0,'com.boubei.tss.dm.ext.CleanPermissionJob','清理残留权限信息','','0 0 01 * * ?'),(3,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-ETL-0100','X','',0,'com.boubei.tss.dm.etl.ByDayETLJob','ETL定时器（每天1点）','','0 00 12 * * ?'),(4,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-ETL-3min','X','',0,'com.boubei.tss.dm.etl.ByIDETLJob','ETL定时器（3分钟）','','0 0/30 * * * ?'),(5,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-p-81','1','',0,'com.boubei.tss.cms.job.ExpireJob','文章过期','','0 02 01 * * ?'),(6,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-p-80','1','',0,'com.boubei.tss.cms.job.PublishJob','文章发布','','0 08 01 * * ?'),(7,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-p-79','1','',0,'com.boubei.tss.cms.job.IndexJob','内容索引','','0 18 01 * * ?'),(8,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-wsETL-3min','X','',0,'com.boubei.tss.matrix.WsIDETLJob','wsETL定时器（3分钟）','','0 0/3 * * * ?'),(9,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-wsETL-0100','X','',0,'com.boubei.tss.matrix.WsDayETLJob','wsETL定时器（每天1点）','','0 0 13 * * ?'),(10,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'Job-wsETL-1h','X','',0,'com.boubei.tss.matrix.WsIDETLJob','wsETL定时器（1h）','','0 0/60 * * * ?');
/*!40000 ALTER TABLE `component_job_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `component_log`
--

DROP TABLE IF EXISTS `component_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `component_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `methodExcuteTime` int(11) DEFAULT NULL,
  `operateTable` varchar(255) NOT NULL,
  `operateTime` datetime DEFAULT NULL,
  `operationCode` varchar(255) DEFAULT NULL,
  `operatorBrowser` varchar(255) DEFAULT NULL,
  `operatorIP` varchar(255) DEFAULT NULL,
  `operatorId` bigint(20) DEFAULT NULL,
  `operatorName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `component_log`
--

LOCK TABLES `component_log` WRITE;
/*!40000 ALTER TABLE `component_log` DISABLE KEYS */;
INSERT INTO `component_log` VALUES (1,'新增/修改了：Param[id=2,code=数据源配置,name=数据源配置,value=<null>,text=<null>,modality=<null>,type=0,description=<null>,parentId=0,seqNo=1,decode=00001,levelNo=1,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',20,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(2,'新增/修改了：Param[id=3,code=default_conn_pool,name=默认数据源,value=connectionpool,text=<null>,modality=0,type=1,description=<null>,parentId=2,seqNo=1,decode=0000100001,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',11,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(3,'新增/修改了：Param[id=4,code=datasource_list,name=数据源列表,value=<null>,text=<null>,modality=1,type=1,description=<null>,parentId=2,seqNo=2,decode=0000100002,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',7,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(4,'新增/修改了：Param[id=5,code=<null>,name=<null>,value=connectionpool,text=本地数据源,modality=1,type=2,description=<null>,parentId=4,seqNo=1,decode=000010000200001,levelNo=3,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',21,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(5,'新增了 (id:1, name:我的站点, parentId:-1)0000100001 节点',28,'站点栏目','2018-04-20 00:26:35','createSite',NULL,NULL,-1,'Admin'),(6,'新增了 (id:2, name:公告栏, parentId:1)000010000100001 节点',16,'站点栏目','2018-04-20 00:26:35','createChannel',NULL,NULL,-1,'Admin'),(7,'新增文章：(id:1, title:欢迎来到它山石的世界) 到(ID: 2) 栏目下',7,'文章','2018-04-20 00:26:35','createArticle',NULL,NULL,-1,'Admin'),(8,'新建/修改了 (id:1, name:布局器组) 节点',9,'门户组件','2018-04-20 00:26:35','saveComponent',NULL,NULL,-1,'Admin'),(9,'新建/修改了 (id:2, name:默认布局器) 节点',3,'门户组件','2018-04-20 00:26:35','saveComponent',NULL,NULL,-1,'Admin'),(10,'新建/修改了 (id:3, name:修饰器组) 节点',4,'门户组件','2018-04-20 00:26:35','saveComponent',NULL,NULL,-1,'Admin'),(11,'新建/修改了 (id:4, name:默认修饰器) 节点',3,'门户组件','2018-04-20 00:26:35','saveComponent',NULL,NULL,-1,'Admin'),(12,'新建/修改了 (id:5, name:portlet组) 节点',4,'门户组件','2018-04-20 00:26:35','saveComponent',NULL,NULL,-1,'Admin'),(13,' 新建/修改了 (id:1, name:应用菜单组) 节点 ',24,'门户导航栏','2018-04-20 00:26:35','saveNavigator',NULL,NULL,-1,'Admin'),(14,'新增/修改了：Param[id=6,code=系统参数,name=系统参数,value=<null>,text=<null>,modality=<null>,type=0,description=<null>,parentId=0,seqNo=2,decode=00002,levelNo=1,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(15,'新增/修改了：Param[id=7,code=sysTitle,name=系统名称,value=它山石-BI,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=1,decode=0000200001,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',8,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(16,'新增/修改了：Param[id=8,code=TEMP_EXPORT_PATH,name=目录（附件）,value=target/temp,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=2,decode=0000200002,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(17,'新增/修改了：Param[id=9,code=upload_path,name=目录（上传）,value=target/upload,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=3,decode=0000200003,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',9,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(18,'新增/修改了：Param[id=10,code=welcomeMsg,name=注册成功欢迎词,value=在这个世界里，您可以自由的管理您的数据，您是自己数据的真正主宰者。如果您是一个企业或个人用户，我们为您提供了丰富多彩的各行各业模块功能，您可以随意挑选试用；如果您是一个开发者，您可以在自己开发目录下自由的开发各种功能，然后发布给其它用户使用。所有这一切，都从注册一个账号开始！,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=4,decode=0000200004,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',7,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(19,'新增/修改了：Param[id=11,code=url.white.list,name=url.white.list,value=/si/user,/si/version,/sysTitle,/subTitle,/regable,.in,.do,.portal,/download?,login.htm,404.html,version.html,redirect.html,_forget.html,_register.htm,/register/form,report_portlet.html,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=5,decode=0000200005,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',7,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(20,'新增/修改了：Param[id=12,code=ip.white.list,name=ip.white.list,value=boubei.com,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=6,decode=0000200006,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',8,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(21,'新增/修改了：Param[id=13,code=email.default,name=邮件服务器（业务）,value=smtp.163.com|lovejava@163.com|jinhetss@163.com|lovejava@163.com|124X109X127X127X123X104,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=7,decode=0000200007,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(22,'新增/修改了：Param[id=14,code=session.cyclelife,name=session.cyclelife,value=3600,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=8,decode=0000200008,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(23,'新增/修改了：Param[id=15,code=email.sys,name=邮件服务器（系统）,value=smtp.163.com|lovejava@163.com|jinhetss@163.com|lovejava@163.com|124X109X127X127X123X104,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=9,decode=0000200009,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',7,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(24,'新增/修改了：Param[id=16,code=report.template.dir,name=目录（报表资源）,value=pages,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=10,decode=0000200010,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',8,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(25,'新增/修改了：Param[id=17,code=error.keyword,name=error.keyword,value=java.sql.SQLException,text=<null>,modality=0,type=1,description=<null>,parentId=6,seqNo=11,decode=0000200011,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(26,'新增/修改了：Param[id=18,code=应用服务配置,name=应用服务配置,value=<null>,text=<null>,modality=<null>,type=0,description=<null>,parentId=0,seqNo=3,decode=00003,levelNo=1,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',14,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(27,'新增/修改了：Param[id=19,code=TSS,name=TSS,value=<server code=\"TSS\" framework=\"tss\" name=\"TSS\" sessionIdName=\"JSESSIONID\" baseURL=\"http://localhost:9090/tss\"/>,text=<null>,modality=0,type=1,description=<null>,parentId=18,seqNo=1,decode=0000300001,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(28,'新增/修改了：Param[id=20,code=BBI,name=BBI,value=<server code=\"BBI\" framework=\"tss\" name=\"BBI\" sessionIdName=\"JSESSIONID\" baseURL=\"http://www.boubei.com/tss\"/>,text=<null>,modality=0,type=1,description=<null>,parentId=18,seqNo=2,decode=0000300002,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',7,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(29,'新增/修改了：Param[id=21,code=XBI,name=XBI,value=<server code=\"XBI\" framework=\"tss\" name=\"XBI\" sessionIdName=\"JSESSIONID\" baseURL=\"http://demo.boubei.com/tss\"/>,text=<null>,modality=0,type=1,description=<null>,parentId=18,seqNo=3,decode=0000300003,levelNo=2,disabled=0,hidden=0,udf1=<null>,udf2=<null>,udf3=<null>,creatorId=-1,createTime=2018-04-20 00:26:35.0,creatorName=<null>,updatorId=<null>,updateTime=<null>,updatorName=<null>,lockVersion=0]',10,'系统参数','2018-04-20 00:26:35','saveParam',NULL,NULL,-1,'Admin'),(30,'新增了：【1, 系统报表, null, null】',21,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(31,'更新了：【1, 系统报表, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(32,'新增了：【2, 访问统计, null, null】',8,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(33,'更新了：【2, 访问统计, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(34,'新增了：【3, GetAllServices, null, null】',9,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(35,'更新了：【3, GetAllServices, null, null】',3,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(36,'新增了：【4, report_visitors, null, null】',8,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(37,'更新了：【4, report_visitors, null, null】',3,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(38,'新增了：【5, report_list, null, null】',11,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(39,'更新了：【5, report_list, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(40,'新增了：【6, visit-summary, null, null】',11,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(41,'更新了：【6, visit-summary, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(42,'新增了：【7, visit-trace, null, null】',9,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(43,'更新了：【7, visit-trace, null, null】',2,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(44,'新增了：【8, visit-trend, null, null】',10,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(45,'更新了：【8, visit-trend, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(46,'新增了：【9, 统计用户访问情况, null, null】',21,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(47,'更新了：【9, 统计用户访问情况, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(48,'新增了：【10, 统计服务访问占比, null, null】',10,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(49,'更新了：【10, 统计服务访问占比, null, null】',2,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(50,'新增了：【11, 统计新增资源数, null, null】',14,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(51,'更新了：【11, 统计新增资源数, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(52,'新增了：【12, 统计用户登录, null, null】',12,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(53,'更新了：【12, 统计用户登录, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(54,'新增了：【13, queryFeedback, null, null】',15,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(55,'更新了：【13, queryFeedback, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(56,'新增了：【14, ETL_LOG, null, null】',11,'报表','2018-04-20 00:26:36','createReport',NULL,NULL,-1,'Admin'),(57,'更新了：【14, ETL_LOG, null, null】',1,'报表','2018-04-20 00:26:36','updateReport',NULL,NULL,-1,'Admin'),(58,'新增了：数据表【id = 1, name = *系统功能】',19,'数据表','2018-04-20 00:26:36','createRecord',NULL,NULL,-1,'Admin'),(59,'修改了：数据表【id = 1, name = *系统功能】',2,'数据表','2018-04-20 00:26:36','updateRecord',NULL,NULL,-1,'Admin'),(60,'新增了：数据表【id = 2, name = 对外用户令牌发放】',22,'数据表','2018-04-20 00:26:36','createRecord',NULL,NULL,-1,'Admin'),(61,'修改了：数据表【id = 2, name = 对外用户令牌发放】',60,'数据表','2018-04-20 00:26:36','updateRecord',NULL,NULL,-1,'Admin'),(62,'新增了：数据表【id = 3, name = 系统使用反馈】',148,'数据表','2018-04-20 00:26:36','createRecord',NULL,NULL,-1,'Admin'),(63,'修改了：数据表【id = 3, name = 系统使用反馈】',16,'数据表','2018-04-20 00:26:36','updateRecord',NULL,NULL,-1,'Admin'),(64,'新增了：数据表【id = 4, name = 功能模块发布】',50,'数据表','2018-04-20 00:26:36','createRecord',NULL,NULL,-1,'Admin'),(65,'修改了：数据表【id = 4, name = 功能模块发布】',16,'数据表','2018-04-20 00:26:36','updateRecord',NULL,NULL,-1,'Admin'),(66,'新增了：数据表【id = 5, name = 系统定时器】',14,'数据表','2018-04-20 00:26:36','createRecord',NULL,NULL,-1,'Admin'),(67,'修改了：数据表【id = 5, name = 系统定时器】',17,'数据表','2018-04-20 00:26:36','updateRecord',NULL,NULL,-1,'Admin'),(68,'新增了：数据表【id = 6, name = ETL任务】',101,'数据表','2018-04-20 00:26:37','createRecord',NULL,NULL,-1,'Admin'),(69,'修改了：数据表【id = 6, name = ETL任务】',14,'数据表','2018-04-20 00:26:37','updateRecord',NULL,NULL,-1,'Admin'),(70,' add some rows: [{remark=, description=, name=用户&组织同步, timestrategy=0 0 02 * * ?, customizeinfo=4,G7, code=Job-sync-user, jobclassname=com.boubei.tss.um.syncdata.SyncUserJob, disabled=1}, {remark=, description=, name=清理残留权限信息, timestrategy=0 0 01 * * ?, customizeinfo=X, code=Job-clean-permission, jobclassname=com.boubei.tss.dm.ext.CleanPermissionJob, disabled=0}, {remark=, description=, name=ETL定时器（每天1点）, timestrategy=0 00 12 * * ?, customizeinfo=X, code=Job-ETL-0100, jobclassname=com.boubei.tss.dm.etl.ByDayETLJob, disabled=0}, {remark=, description=, name=ETL定时器（3分钟）, timestrategy=0 0/30 * * * ?, customizeinfo=X, code=Job-ETL-3min, jobclassname=com.boubei.tss.dm.etl.ByIDETLJob, disabled=0}, {remark=, description=, name=文章过期, timestrategy=0 02 01 * * ?, customizeinfo=1, code=Job-p-81, jobclassname=com.boubei.tss.cms.job.ExpireJob, disabled=0}, {remark=, description=, name=文章发布, timestrategy=0 08 01 * * ?, customizeinfo=1, code=Job-p-80, jobclassname=com.boubei.tss.cms.job.PublishJob, disabled=0}, {remark=, description=, name=内容索引, timestrategy=0 18 01 * * ?, customizeinfo=1, code=Job-p-79, jobclassname=com.boubei.tss.cms.job.IndexJob, disabled=0}, {remark=, description=, name=wsETL定时器（3分钟）, timestrategy=0 0/3 * * * ?, customizeinfo=X, code=Job-wsETL-3min, jobclassname=com.boubei.tss.matrix.WsIDETLJob, disabled=0}, {remark=, description=, name=wsETL定时器（每天1点）, timestrategy=0 0 13 * * ?, customizeinfo=X, code=Job-wsETL-0100, jobclassname=com.boubei.tss.matrix.WsDayETLJob, disabled=0}, {remark=, description=, name=wsETL定时器（1h）, timestrategy=0 0/60 * * * ?, customizeinfo=X, code=Job-wsETL-1h, jobclassname=com.boubei.tss.matrix.WsIDETLJob, disabled=0}]',0,'系统定时器','2018-04-20 00:26:37','create, ',NULL,NULL,-1,'Admin'),(71,' add some rows: [{startid=, manager=, jobname=wsETL定时器（每天1点）, remark=, status=opened, sourcescript=select  \'report\' type, date_format(accessTime, \'%Y-%m-%d\') day, date_format(accessTime, \'%H\') hour,  	ROUND(avg(runningTime)) rt, count(*) visitnum, count(distinct l.userId) visitusernum  from dm_access_log l  where 1=1     and l.accessTime >= \'${param1}\'      and l.accessTime < \'${param2}\'  group by  date_format(accessTime,\'%H\')  union all SELECT operateTable type, date_format(operatetime, \'%Y-%m-%d\') day, date_format(operatetime, \'%H\') hour, 0 rt,   count(*) visitnum, count(distinct operatorid) visitusernum  FROM component_log  WHERE operateTable like \'record-%\'    and operatetime >= \'${param1}\'     and operatetime < \'${param2}\' group by  date_format(operatetime,\'%H\') order by hour asc, targetscript=71, prerepeatsql=, type=wsDay, startday=2017-07-16 00:00:00.0, jobid=10, applier=系统管理员, priority=, name=收集访问情况, repeatdays=0, sourceds=connectionpool, applyday=2017-07-11 09:11:31.0, targetds=restful-WebService}, {startid=80, manager=, jobname=wsETL定时器（1h）, remark=, status=opened, sourcescript=SELECT id, operatetable, operationcode, operatetime, operatorip, operatorbrowser, operatorname, content  FROM component_log  WHERE operateTable IN (\'录入表\',\'报表\',\'站点栏目\',\'门户结构\',\'门户组件\',\'站点栏目\',\'文章\',\'角色\',\'用户\',\'用户登录\',\'系统参数\',\'系统异常\')    AND operateTime > \'2017-07-16\'    AND id > ?, targetscript=70, prerepeatsql=, type=wsID, startday=, jobid=11, applier=系统管理员, priority=, name=收集操作日志, repeatdays=, sourceds=connectionpool, applyday=2017-07-11 09:06:19.0, targetds=restful-WebService}, {startid=, manager=, jobname=wsETL定时器（每天1点）, remark=, status=opened, sourcescript=select name, createTime ct, updateTime ut, lockVersion, rctable, define, datasource, customizejs, customizepage, customizetj, customizeGrid, needlog, needfile, batchimp  from dm_record  where type = 1  and id > 5 and ifnull(updateTime, createTime) >= ?      and ifnull(updateTime, createTime) < ?, targetscript=69, prerepeatsql=, type=byDay, startday=2017-07-16 00:00:00.0, jobid=10, applier=系统管理员, priority=, name=收集每天录入表更新, repeatdays=0, sourceds=connectionpool, applyday=2017-07-11 09:02:07.0, targetds=restful-WebService}, {startid=, manager=, jobname=wsETL定时器（每天1点）, remark=, status=opened, sourcescript=select name, createTime ct, updateTime ut, lockVersion, param, script, datasource, displayuri, paramuri, needlog, mailable  from dm_report  where type = 1  and id > 14  and ifnull(updateTime, createTime) >= ?      and ifnull(updateTime, createTime) < ?, targetscript=68, prerepeatsql=, type=wsDay, startday=2017-07-16 00:00:00.0, jobid=10, applier=系统管理员, priority=, name=收集每天报表更新, repeatdays=0, sourceds=connectionpool, applyday=2017-07-11 08:53:22.0, targetds=restful-WebService}, {startid=, manager=JK, jobname=ETL定时器（每天1点）, remark=, status=opened, sourcescript=select DATE_FORMAT(day, \'%m-%d\')  day,  round( sum(fee), 1 )  money from car_mr_jz where  day >= ? and day < ? group by day, targetscript=insert into car_mr_daily(day,money) values(?,?), prerepeatsql=delete from car_mr_daily where day=?, type=byDay, startday=2017-03-01 00:00:00.0, jobid=3, applier=系统管理员, priority=101, name=任务-每日对账, repeatdays=7, sourceds=connpool-data, applyday=2017-06-04 14:25:36.0, targetds=connpool-data}, {startid=0, manager=JK, jobname=ETL定时器（3分钟）, remark=, status=opened, sourcescript=SELECT * FROM  portal_flowrate  where id > ?, targetscript=insert into portal_flowrate(id,ip,pageid,visitTime) values(?,?,?,?), prerepeatsql=select max(id) maxid from portal_flowrate, type=byID, startday=, jobid=4, applier=系统管理员, priority=, name=任务-抽取访问流水, repeatdays=, sourceds=connectionpool, applyday=2017-06-04 14:39:59.0, targetds=connpool-data}]',0,'ETL任务','2018-04-20 00:26:37','create, ',NULL,NULL,-1,'Admin'),(72,'新增了：【15, 我的报表, null, null】',28,'报表','2018-04-20 00:26:37','createReport',NULL,NULL,-1,'Admin');
/*!40000 ALTER TABLE `component_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `component_param`
--

DROP TABLE IF EXISTS `component_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `component_param` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `hidden` int(11) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `modality` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `udf1` varchar(255) DEFAULT NULL,
  `udf2` varchar(255) DEFAULT NULL,
  `udf3` varchar(255) DEFAULT NULL,
  `value` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `component_param`
--

LOCK TABLES `component_param` WRITE;
/*!40000 ALTER TABLE `component_param` DISABLE KEYS */;
INSERT INTO `component_param` VALUES (1,NULL,NULL,NULL,0,NULL,NULL,NULL,'0','00000',NULL,NULL,1,NULL,NULL,'0',NULL,NULL,'0',NULL,NULL,NULL,NULL,'0'),(2,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'数据源配置','00001',NULL,0,0,1,NULL,'数据源配置',0,1,NULL,0,NULL,NULL,NULL,NULL),(3,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'default_conn_pool','0000100001',NULL,0,0,2,0,'默认数据源',2,1,NULL,1,NULL,NULL,NULL,'connectionpool'),(4,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'datasource_list','0000100002',NULL,0,0,2,1,'数据源列表',2,2,NULL,1,NULL,NULL,NULL,NULL),(5,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,NULL,'000010000200001',NULL,0,0,3,1,NULL,4,1,'本地数据源',2,NULL,NULL,NULL,'connectionpool'),(6,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'系统参数','00002',NULL,0,0,1,NULL,'系统参数',0,2,NULL,0,NULL,NULL,NULL,NULL),(7,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'sysTitle','0000200001',NULL,0,0,2,0,'系统名称',6,1,NULL,1,NULL,NULL,NULL,'它山石-BI'),(8,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'TEMP_EXPORT_PATH','0000200002',NULL,0,0,2,0,'目录（附件）',6,2,NULL,1,NULL,NULL,NULL,'target/temp'),(9,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'upload_path','0000200003',NULL,0,0,2,0,'目录（上传）',6,3,NULL,1,NULL,NULL,NULL,'target/upload'),(10,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'welcomeMsg','0000200004',NULL,0,0,2,0,'注册成功欢迎词',6,4,NULL,1,NULL,NULL,NULL,'在这个世界里，您可以自由的管理您的数据，您是自己数据的真正主宰者。如果您是一个企业或个人用户，我们为您提供了丰富多彩的各行各业模块功能，您可以随意挑选试用；如果您是一个开发者，您可以在自己开发目录下自由的开发各种功能，然后发布给其它用户使用。所有这一切，都从注册一个账号开始！'),(11,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'url.white.list','0000200005',NULL,0,0,2,0,'url.white.list',6,5,NULL,1,NULL,NULL,NULL,'/si/user,/si/version,/sysTitle,/subTitle,/regable,.in,.do,.portal,/download?,login.htm,404.html,version.html,redirect.html,_forget.html,_register.htm,/register/form,report_portlet.html'),(12,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'ip.white.list','0000200006',NULL,0,0,2,0,'ip.white.list',6,6,NULL,1,NULL,NULL,NULL,'boubei.com'),(13,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'email.default','0000200007',NULL,0,0,2,0,'邮件服务器（业务）',6,7,NULL,1,NULL,NULL,NULL,'smtp.163.com|lovejava@163.com|jinhetss@163.com|lovejava@163.com|124X109X127X127X123X104'),(14,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'session.cyclelife','0000200008',NULL,0,0,2,0,'session.cyclelife',6,8,NULL,1,NULL,NULL,NULL,'3600'),(15,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'email.sys','0000200009',NULL,0,0,2,0,'邮件服务器（系统）',6,9,NULL,1,NULL,NULL,NULL,'smtp.163.com|lovejava@163.com|jinhetss@163.com|lovejava@163.com|124X109X127X127X123X104'),(16,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'report.template.dir','0000200010',NULL,0,0,2,0,'目录（报表资源）',6,10,NULL,1,NULL,NULL,NULL,'pages'),(17,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'error.keyword','0000200011',NULL,0,0,2,0,'error.keyword',6,11,NULL,1,NULL,NULL,NULL,'java.sql.SQLException'),(18,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'应用服务配置','00003',NULL,0,0,1,NULL,'应用服务配置',0,3,NULL,0,NULL,NULL,NULL,NULL),(19,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'TSS','0000300001',NULL,0,0,2,0,'TSS',18,1,NULL,1,NULL,NULL,NULL,'<server code=\"TSS\" framework=\"tss\" name=\"TSS\" sessionIdName=\"JSESSIONID\" baseURL=\"http://localhost:9090/tss\"/>'),(20,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'BBI','0000300002',NULL,0,0,2,0,'BBI',18,2,NULL,1,NULL,NULL,NULL,'<server code=\"BBI\" framework=\"tss\" name=\"BBI\" sessionIdName=\"JSESSIONID\" baseURL=\"http://www.boubei.com/tss\"/>'),(21,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'XBI','0000300003',NULL,0,0,2,0,'XBI',18,3,NULL,1,NULL,NULL,NULL,'<server code=\"XBI\" framework=\"tss\" name=\"XBI\" sessionIdName=\"JSESSIONID\" baseURL=\"http://demo.boubei.com/tss\"/>');
/*!40000 ALTER TABLE `component_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_access_log`
--

DROP TABLE IF EXISTS `dm_access_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_access_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accessTime` datetime DEFAULT NULL,
  `className` varchar(255) NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `methodCnName` varchar(255) NOT NULL,
  `methodName` varchar(100) NOT NULL,
  `params` longtext,
  `runningTime` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_access_log`
--

LOCK TABLES `dm_access_log` WRITE;
/*!40000 ALTER TABLE `dm_access_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dm_access_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_empty`
--

DROP TABLE IF EXISTS `dm_empty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_empty` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `x` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_empty`
--

LOCK TABLES `dm_empty` WRITE;
/*!40000 ALTER TABLE `dm_empty` DISABLE KEYS */;
/*!40000 ALTER TABLE `dm_empty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_etl_task`
--

DROP TABLE IF EXISTS `dm_etl_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_etl_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `applier` varchar(255) NOT NULL,
  `applyDay` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `jobId` bigint(20) NOT NULL,
  `jobName` varchar(255) DEFAULT NULL,
  `manager` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `preRepeatSQL` varchar(255) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `remark` longtext,
  `repeatDays` int(11) DEFAULT NULL,
  `sourceDS` varchar(255) NOT NULL,
  `sourceScript` longtext NOT NULL,
  `startDay` datetime DEFAULT NULL,
  `startID` bigint(20) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `targetDS` varchar(255) NOT NULL,
  `targetScript` longtext NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dm_etl_task_name` (`name`),
  KEY `idx_dm_etl_task_type` (`type`),
  KEY `idx_dm_etl_task_applier` (`applier`),
  KEY `idx_dm_etl_task_domain` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_etl_task`
--

LOCK TABLES `dm_etl_task` WRITE;
/*!40000 ALTER TABLE `dm_etl_task` DISABLE KEYS */;
INSERT INTO `dm_etl_task` VALUES (1,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'系统管理员','2017-07-11 09:11:31',NULL,10,'wsETL定时器（每天1点）','','收集访问情况','',NULL,'',0,'connectionpool','select  \'report\' type, date_format(accessTime, \'%Y-%m-%d\') day, date_format(accessTime, \'%H\') hour,  	ROUND(avg(runningTime)) rt, count(*) visitnum, count(distinct l.userId) visitusernum  from dm_access_log l  where 1=1     and l.accessTime >= \'${param1}\'      and l.accessTime < \'${param2}\'  group by  date_format(accessTime,\'%H\')  union all SELECT operateTable type, date_format(operatetime, \'%Y-%m-%d\') day, date_format(operatetime, \'%H\') hour, 0 rt,   count(*) visitnum, count(distinct operatorid) visitusernum  FROM component_log  WHERE operateTable like \'record-%\'    and operatetime >= \'${param1}\'     and operatetime < \'${param2}\' group by  date_format(operatetime,\'%H\') order by hour asc','2017-07-16 00:00:00',NULL,'opened','restful-WebService','71','wsDay'),(2,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'系统管理员','2017-07-11 09:06:19',NULL,11,'wsETL定时器（1h）','','收集操作日志','',NULL,'',NULL,'connectionpool','SELECT id, operatetable, operationcode, operatetime, operatorip, operatorbrowser, operatorname, content  FROM component_log  WHERE operateTable IN (\'录入表\',\'报表\',\'站点栏目\',\'门户结构\',\'门户组件\',\'站点栏目\',\'文章\',\'角色\',\'用户\',\'用户登录\',\'系统参数\',\'系统异常\')    AND operateTime > \'2017-07-16\'    AND id > ?',NULL,80,'opened','restful-WebService','70','wsID'),(3,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'系统管理员','2017-07-11 09:02:07',NULL,10,'wsETL定时器（每天1点）','','收集每天录入表更新','',NULL,'',0,'connectionpool','select name, createTime ct, updateTime ut, lockVersion, rctable, define, datasource, customizejs, customizepage, customizetj, customizeGrid, needlog, needfile, batchimp  from dm_record  where type = 1  and id > 5 and ifnull(updateTime, createTime) >= ?      and ifnull(updateTime, createTime) < ?','2017-07-16 00:00:00',NULL,'opened','restful-WebService','69','byDay'),(4,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'系统管理员','2017-07-11 08:53:22',NULL,10,'wsETL定时器（每天1点）','','收集每天报表更新','',NULL,'',0,'connectionpool','select name, createTime ct, updateTime ut, lockVersion, param, script, datasource, displayuri, paramuri, needlog, mailable  from dm_report  where type = 1  and id > 14  and ifnull(updateTime, createTime) >= ?      and ifnull(updateTime, createTime) < ?','2017-07-16 00:00:00',NULL,'opened','restful-WebService','68','wsDay'),(5,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'系统管理员','2017-06-04 14:25:36',NULL,3,'ETL定时器（每天1点）','JK','任务-每日对账','delete from car_mr_daily where day=?',101,'',7,'connpool-data','select DATE_FORMAT(day, \'%m-%d\')  day,  round( sum(fee), 1 )  money from car_mr_jz where  day >= ? and day < ? group by day','2017-03-01 00:00:00',NULL,'opened','connpool-data','insert into car_mr_daily(day,money) values(?,?)','byDay'),(6,'2018-04-20 00:26:37','Admin',NULL,NULL,NULL,0,'系统管理员','2017-06-04 14:39:59',NULL,4,'ETL定时器（3分钟）','JK','任务-抽取访问流水','select max(id) maxid from portal_flowrate',NULL,'',NULL,'connectionpool','SELECT * FROM  portal_flowrate  where id > ?',NULL,0,'opened','connpool-data','insert into portal_flowrate(id,ip,pageid,visitTime) values(?,?,?,?)','byID');
/*!40000 ALTER TABLE `dm_etl_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_etl_task_log`
--

DROP TABLE IF EXISTS `dm_etl_task_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_etl_task_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dataDay` varchar(255) DEFAULT NULL,
  `detail` longtext NOT NULL,
  `exception` varchar(255) DEFAULT NULL,
  `excuteTime` datetime DEFAULT NULL,
  `maxID` bigint(20) DEFAULT NULL,
  `runningMS` bigint(20) NOT NULL,
  `taskId` bigint(20) NOT NULL,
  `taskName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_etl_task_log`
--

LOCK TABLES `dm_etl_task_log` WRITE;
/*!40000 ALTER TABLE `dm_etl_task_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `dm_etl_task_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_permission_record`
--

DROP TABLE IF EXISTS `dm_permission_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_permission_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_permission_record`
--

LOCK TABLES `dm_permission_record` WRITE;
/*!40000 ALTER TABLE `dm_permission_record` DISABLE KEYS */;
INSERT INTO `dm_permission_record` VALUES (1,1,1,'1',2,0,'root',-1),(2,1,1,'2',2,0,'root',-1),(3,1,1,'3',2,0,'root',-1),(4,1,1,'4',2,0,'root',-1),(5,1,1,'5',2,0,'root',-1),(6,1,1,'1',2,1,'*系统功能',-1),(7,1,1,'2',2,1,'*系统功能',-1),(8,1,1,'3',2,1,'*系统功能',-1),(9,1,1,'4',2,1,'*系统功能',-1),(10,1,1,'5',2,1,'*系统功能',-1),(11,1,1,'1',2,2,'对外用户令牌发放',-1),(12,1,1,'2',2,2,'对外用户令牌发放',-1),(13,1,1,'3',2,2,'对外用户令牌发放',-1),(14,1,1,'4',2,2,'对外用户令牌发放',-1),(15,1,1,'5',2,2,'对外用户令牌发放',-1),(16,1,1,'1',2,3,'系统使用反馈',-1),(17,1,1,'2',2,3,'系统使用反馈',-1),(18,1,1,'3',2,3,'系统使用反馈',-1),(19,1,1,'4',2,3,'系统使用反馈',-1),(20,1,1,'5',2,3,'系统使用反馈',-1),(21,1,1,'1',2,4,'功能模块发布',-1),(22,1,1,'2',2,4,'功能模块发布',-1),(23,1,1,'3',2,4,'功能模块发布',-1),(24,1,1,'4',2,4,'功能模块发布',-1),(25,1,1,'5',2,4,'功能模块发布',-1),(26,1,1,'1',2,5,'系统定时器',-1),(27,1,1,'2',2,5,'系统定时器',-1),(28,1,1,'3',2,5,'系统定时器',-1),(29,1,1,'4',2,5,'系统定时器',-1),(30,1,1,'5',2,5,'系统定时器',-1),(31,1,1,'1',2,6,'ETL任务',-1),(32,1,1,'2',2,6,'ETL任务',-1),(33,1,1,'3',2,6,'ETL任务',-1),(34,1,1,'4',2,6,'ETL任务',-1),(35,1,1,'5',2,6,'ETL任务',-1),(36,0,0,'1',1,5,'系统定时器',-9),(37,0,0,'1',1,5,'系统定时器',-8),(38,0,0,'1',1,6,'ETL任务',-8),(39,0,0,'1',1,3,'系统使用反馈',-10000),(40,0,0,'1',1,4,'功能模块发布',-9),(41,1,1,'1',2,7,'我的功能',-1),(42,1,1,'2',2,7,'我的功能',-1),(43,1,1,'3',2,7,'我的功能',-1),(44,1,1,'4',2,7,'我的功能',-1),(45,1,1,'5',2,7,'我的功能',-1),(46,0,0,'1',1,0,'root',-8),(47,0,0,'1',1,0,'root',-9),(48,0,0,'1',1,7,'我的功能',-8),(49,1,0,'1',1,7,'我的功能',-9);
/*!40000 ALTER TABLE `dm_permission_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_permission_report`
--

DROP TABLE IF EXISTS `dm_permission_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_permission_report` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_permission_report`
--

LOCK TABLES `dm_permission_report` WRITE;
/*!40000 ALTER TABLE `dm_permission_report` DISABLE KEYS */;
INSERT INTO `dm_permission_report` VALUES (1,1,1,'1',2,0,'root',-1),(2,1,1,'2',2,0,'root',-1),(3,1,1,'3',2,0,'root',-1),(4,1,1,'4',2,0,'root',-1),(5,1,1,'1',2,1,'系统报表',-1),(6,1,1,'2',2,1,'系统报表',-1),(7,1,1,'3',2,1,'系统报表',-1),(8,1,1,'4',2,1,'系统报表',-1),(9,1,1,'1',2,2,'访问统计',-1),(10,1,1,'2',2,2,'访问统计',-1),(11,1,1,'3',2,2,'访问统计',-1),(12,1,1,'4',2,2,'访问统计',-1),(13,1,1,'1',2,3,'GetAllServices',-1),(14,1,1,'2',2,3,'GetAllServices',-1),(15,1,1,'3',2,3,'GetAllServices',-1),(16,1,1,'4',2,3,'GetAllServices',-1),(17,1,1,'1',2,4,'report_visitors',-1),(18,1,1,'2',2,4,'report_visitors',-1),(19,1,1,'3',2,4,'report_visitors',-1),(20,1,1,'4',2,4,'report_visitors',-1),(21,1,1,'1',2,5,'report_list',-1),(22,1,1,'2',2,5,'report_list',-1),(23,1,1,'3',2,5,'report_list',-1),(24,1,1,'4',2,5,'report_list',-1),(25,1,1,'1',2,6,'visit-summary',-1),(26,1,1,'2',2,6,'visit-summary',-1),(27,1,1,'3',2,6,'visit-summary',-1),(28,1,1,'4',2,6,'visit-summary',-1),(29,1,1,'1',2,7,'visit-trace',-1),(30,1,1,'2',2,7,'visit-trace',-1),(31,1,1,'3',2,7,'visit-trace',-1),(32,1,1,'4',2,7,'visit-trace',-1),(33,1,1,'1',2,8,'visit-trend',-1),(34,1,1,'2',2,8,'visit-trend',-1),(35,1,1,'3',2,8,'visit-trend',-1),(36,1,1,'4',2,8,'visit-trend',-1),(37,1,1,'1',2,9,'统计用户访问情况',-1),(38,1,1,'2',2,9,'统计用户访问情况',-1),(39,1,1,'3',2,9,'统计用户访问情况',-1),(40,1,1,'4',2,9,'统计用户访问情况',-1),(41,1,1,'1',2,10,'统计服务访问占比',-1),(42,1,1,'2',2,10,'统计服务访问占比',-1),(43,1,1,'3',2,10,'统计服务访问占比',-1),(44,1,1,'4',2,10,'统计服务访问占比',-1),(45,1,1,'1',2,11,'统计新增资源数',-1),(46,1,1,'2',2,11,'统计新增资源数',-1),(47,1,1,'3',2,11,'统计新增资源数',-1),(48,1,1,'4',2,11,'统计新增资源数',-1),(49,1,1,'1',2,12,'统计用户登录',-1),(50,1,1,'2',2,12,'统计用户登录',-1),(51,1,1,'3',2,12,'统计用户登录',-1),(52,1,1,'4',2,12,'统计用户登录',-1),(53,1,1,'1',2,13,'queryFeedback',-1),(54,1,1,'2',2,13,'queryFeedback',-1),(55,1,1,'3',2,13,'queryFeedback',-1),(56,1,1,'4',2,13,'queryFeedback',-1),(57,1,1,'1',2,14,'ETL_LOG',-1),(58,1,1,'2',2,14,'ETL_LOG',-1),(59,1,1,'3',2,14,'ETL_LOG',-1),(60,1,1,'4',2,14,'ETL_LOG',-1),(61,1,1,'1',2,15,'我的报表',-1),(62,1,1,'2',2,15,'我的报表',-1),(63,1,1,'3',2,15,'我的报表',-1),(64,1,1,'4',2,15,'我的报表',-1),(65,0,0,'1',1,0,'root',-8),(66,0,0,'1',1,0,'root',-9),(67,0,0,'1',1,15,'我的报表',-8),(68,1,0,'1',1,15,'我的报表',-9);
/*!40000 ALTER TABLE `dm_permission_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_record`
--

DROP TABLE IF EXISTS `dm_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `batchImp` int(11) DEFAULT NULL,
  `customizeGrid` longtext,
  `customizeJS` longtext,
  `customizePage` varchar(255) DEFAULT NULL,
  `customizeTJ` longtext,
  `datasource` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `define` longtext,
  `disabled` int(11) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `needFile` int(11) DEFAULT NULL,
  `needLog` int(11) DEFAULT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `remark` longtext,
  `seqNo` int(11) DEFAULT NULL,
  `rctable` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `workflow` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_record`
--

LOCK TABLES `dm_record` WRITE;
/*!40000 ALTER TABLE `dm_record` DISABLE KEYS */;
INSERT INTO `dm_record` VALUES (1,'2018-04-20 00:26:36',-1,NULL,2,'2018-04-20 00:26:36',-1,NULL,0,NULL,NULL,NULL,'','connectionpool','0000100001',NULL,0,2,'*系统功能',0,0,0,'open it',1,'dm_rc_1023851948',0,NULL),(2,'2018-04-20 00:26:36',-1,NULL,2,'2018-04-20 00:26:36',-1,NULL,0,'function downloadLicense() {\n  var grid = $.G(\"grid\");\n  var rowID  = grid.getColumnValue(\"id\");\n  window.open(\"/tss/auth/license/\" + rowID);\n}','$(\"#description\").value(\n  \"1、在【用户】填入用户在TSS的注册账号 \\n \" + \n  \"2、在【资源】填入报表或录入的ID或名称，如果令牌类型为#单点登录#，则填入其它系统的系统编码 \\n \" + \n  \"3、【令牌】内容根据填入信息及时间戳自动生成，也可以人为生成后复制进来 \\n \" + \n  \"4、令牌有效期默认10年，您可以根据需要进行调整 \\n \" + \n  \"5、令牌生成后，复制token值给授予人，提醒其注意保密；如泄露需及时重新申请重置token \\n \"\n); \n$(\"#description\").css(\"border\", \"none\").css(\"padding\", \"3px\").css(\"line-height\", \"18px\");\nforbid(\"description\"); \n!isNew() && forbid(\"token\"); \n\n$(\"#user\").blur( genToken );  $(\"#type\").blur( genToken );  $(\"#resource\").blur( genToken );  $(\"#expiretime\").blur( genToken );  \n\nfunction genToken() {\n     if( !isNew() ) return;\n     if( $(\"#type\").value() == \'License\' ) { \n        if( $(\"#user\").value() && $(\"#resource\").value() && $(\"#expiretime\").value() ) {\n          var resource = $(\"#resource\").value().split(\"|\");\n          var params = {};\n          params.product = resource[0].trim();\n          params.version = resource[1].trim();\n          params.owner = $(\"#user\").value();\n          params.expiry = $(\"#expiretime\").value();\n          tssJS.post(\"/tss/auth/license\", params, function(result) {\n            forbid(\"token\");\n            updateField(\"token\",  result.license);\n          });\n        }        \n     } else {\n       var token = $.now() + $(\"#user\").value() + $(\"#type\").value() + $(\"#resource\").value()  + $(\"#expireTime\").value();\n       updateField(\"token\",  hex_md5( token ));\n     }\n}\n\npreListener = function() { \n   if( !$(\"#token\").value() || $(\"#token\").value().length < 32 ) {\n      $(\"#token\").notice(\"token不能少于32位\");\n      return false;\n   }\n   $(\"#description\").value(\"\");\n   if( $(\"#type\").value() == \'License\' ) { \n       updateField(\"remark\",  \"<a href=\'javascript:void(0)\' onclick=\'downloadLicense();\'>下载</a>\");\n   }\n   return true;\n}\n\nafterListener = function() {\n  if( isNew() ) {\n     $.tssTip(\"令牌添加成功，把令牌里Token值复制给此令牌的授予人，及可正式使用此令牌\");\n  }\n}',NULL,'','connectionpool','000010000100001','[\n  {\'label\':\'用户\',\'code\':\'user\',\'nullable\':\'false\',\'isparam\':\'true\'},\n  {\'label\':\'令牌类型\',\'code\':\'type\',\'nullable\':\'false\',\'isparam\':\'true\',\'options\':{\'codes\':\'D1|D2|SSO|License\',\'names\':\'数据服务|数据表|单点登录|许可证\'},\'width\':\'150\'},\n  {\'label\':\'资源\',\'code\':\'resource\',\'nullable\':\'false\',\'isparam\':\'true\'},\n  {\'label\':\'令牌\',\'code\':\'token\',\'nullable\':\'false\',\'isparam\':\'true\',\'width\':\'350\',\'cwidth\':\'120px\',\'height\':\'110\'},\n  {\'label\':\'过期时间\',\'code\':\'expireTime\',\'nullable\':\'false\',\'isparam\':\'true\',\'type\':\'date\',\'defaultValue\':\'today+3650\',\'cwidth\':\'40px\'},\n  {\'label\':\'备注\',\'code\':\'remark\',\'height\':\'80\',\'cwidth\':\'100px\',\'width\':\'300\'},\n  {\'label\':\'说明\',\'code\':\'description\',\'height\':\'170\',\'width\':\'350\',\'cwidth\':\'20px\'}\n]',0,3,'对外用户令牌发放',0,1,1,'用于对外开放接口、单点登录、发放License许可证。。。。。。',1,'um_user_token',1,NULL),(3,'2018-04-20 00:26:36',-1,NULL,2,'2018-04-20 00:26:36',-1,NULL,0,'!openItemId && showDetail(\'_new\');\naddOptBtn(\'上传附件\', function() { \n    var itemId = $.G(\"grid\").getColumnValue(\"id\"); \n    if( !itemId ) return $.alert(\"请先选中反馈的记录，然后再上传附件，如果没有反馈的记录则点#新增#按钮先创建一条反馈记录。\");\n    else manageAttach(itemId);\n});','updateField(\"udf1\",   decodeURI( $.Query.get(\"udf\") || \"\" ));\n$(\"#remark\").value(\n  \"1、欢迎把您使用系统过程中发现的问题反馈给我们 \\n \" + \n  \"2、反馈内容可以是系统问题、改进意见、期望功能等 \\n \" + \n  \"3、除了文字描述，还可以通过上传截图等附件进行补充，附件可以是文档、截图等任何有助于说明反馈问题的文件 \\n \" + \n  \"4、我们在收到您的问题反馈后，会把最新的处理结果通知给您 \\n \" + \n  \"5、请尽量留下您的个人联系方式，以便于我们向您详询，感谢您的支持\\n\"\n); \n$(\"#remark\").css(\"border\", \"none\").css(\"padding\", \"3px\").css(\"line-height\", \"18px\");\nforbid(\"remark,udf1\");\nforbid(\"processing\", \"-1\");\nforbid(\"processor\", \"-1\");\n\npreListener = function() { \n   if( !$(\"#content\").value() || $(\"#content\").value().length < 2 ) {\n      $(\"#content\").notice(\"请输入4个字以上\");\n      return false;\n   }\n   $(\"#remark\").value(\"\");\n   return true;\n}\n\nafterListener = function() {\n  if( isNew() ) {\n     $.tssTip(\"反馈成功，您可以继续为该反馈添加截图等附件；您也可以继续反馈其它问题，感谢您的支持！\");\n  }\n}',NULL,'','connectionpool','000010000100002','[\n  {\'label\':\'所在模块\',\'code\':\'module\',\'options\':{\'codes\':\'数据管理|用户权限|内容管理|门户展示|系统辅助|其它模块\'},\'nullable\':\'false\',\'isparam\':\'true\',\'defaultValue\':\'数据管理\'},\n  {\'label\':\'反馈类型\',\'code\':\'type\',\'options\':{\'codes\':\'系统异常|改进意见|吐槽\'},\'defaultValue\':\'系统异常\',\'cwidth\':\'60px\'},\n  {\'label\':\'反馈内容\',\'code\':\'content\',\'type\':\'string\',\'nullable\':\'false\',\'width\':\'350\',\'height\':\'120\',\'cwidth\':\'200px\'},\n  {\'label\':\'截图\',\'type\':\'file\',\'code\':\'pic\'},\n  {\'label\':\'环境描述\',\'code\':\'env\',\'width\':\'350\'},\n  {\'label\':\'自定义\',\'code\':\'udf1\',\'cwidth\':\'50px\'},\n  {\'label\':\'反馈人\',\'code\':\'commiter\',\'type\':\'string\',\'nullable\':\'true\',\'width\':\'300\',\'isparam\':\'true\',\'cwidth\':\'80px\'},\n  {\'label\':\'状态\',\'options\':{\'codes\':\'新建|正在解决|已解决|未解决|非异常|又出现了|没能重现|关闭\'},\'nullable\':\'false\',\'defaultValue\':\'新建\',\'code\':\'state\',\'cwidth\':\'60px\'},\n  {\'label\':\'处理结果\',\'code\':\'processing\',\'type\':\'string\',\'nullable\':\'true\',\'width\':\'350\',\'height\':\'60\',\'cwidth\':\'100px\'},\n  {\'label\':\'处理人\',\'code\':\'processor\',\'type\':\'string\',\'nullable\':\'true\',\'width\':\'300\',\'isparam\':\'true\'},\n  {\'label\':\'说明\',\'code\':\'remark\',\'type\':\'string\',\'nullable\':\'true\',\'width\':\'350\',\'height\':\'144\'}\n]',0,3,'系统使用反馈',1,1,1,'用来收集用户在使用系统过程中的反馈内容',2,'x_feedback',1,NULL),(4,'2018-04-20 00:26:36',-1,NULL,2,'2018-04-20 00:26:36',-1,NULL,0,'function impModule() {\n    function checkFileWrong(subfix) { \n        return subfix.indexOf(\'zip\') < 0 && subfix.indexOf(\'json\') < 0;\n    }\n    var url = URL_UPLOAD_FILE + \"?afterUploadClass=com.boubei.tssx.XModule\";\n    var importDiv = createImportDiv(\"请点击图标选择JSON或ZIP文件导入\", checkFileWrong, url);\n    $(importDiv).show();\n}\naddOptBtn(\'导入模块\', impModule);\n\nvar mi = {\n        label:\"导出模块\",\n        callback: function() {\n		    var moduleId  = $.G(\"grid\").getColumnValue(\"id\");\n		    $(\"#downloadFrame\").attr( \"src\", \"/tss/auth/modulex/exp/\" + moduleId );\n		},\n        icon:\"images/export.gif\",\n        visible:function() { return true; }\n }\n$1(\"grid\").contextmenu.addItem(mi);',NULL,NULL,'','connectionpool','000010000100003','[\n  {\'label\':\'模块名称\',\'code\':\'module\',\'nullable\':\'false\',\'cwidth\':\'70px\'},\n  {\'label\':\'归类\',\'code\':\'kind\',\'cwidth\':\'70px\'},\n  {\'label\':\'角色集\',\'code\':\'roles\',\'nullable\':\'false\',\'jsonUrl\':\'/tss/auth/service/roles\',\'multiple\':\'true\',\'cwidth\':\'70px\'},\n  {\'label\':\'资源文件\',\'code\':\'resource\',\'width\':\'350\',\'height\':\'60\'},\n  {\'label\':\'状态\',\'code\':\'status\',\'options\':{\'codes\':\'creating|opened|closed\',\'names\':\'开发中|已发布|关闭\'}},\n  {\'label\':\'介绍\',\'code\':\'description\',\'width\':\'350px\',\'height\':\'120px\',\'cwidth\':\'120px\'},\n  {\'label\':\'备注\',\'code\':\'remark\',\'width\':\'350px\',\'height\':\'120px\',\'cwidth\':\'100px\'}\n]',0,3,'功能模块发布',1,1,1,NULL,3,'cloud_module_def',1,NULL),(5,'2018-04-20 00:26:36',-1,NULL,2,'2018-04-20 00:26:36',-1,NULL,1,NULL,'$(\"#description\").css(\"border\", \"none\").css(\"padding\", \"3px\").css(\"line-height\", \"18px\");\n$(\"#description\").value(\n  \"1、【Job执行类】填入定时器JAVA类完整路径 \\n \" + \n  \"2、【定时策略】默认为每天凌晨1点执行，配置规则可以搜索#java quartz# \\n \" + \n  \"3、【Job参数】可选填入定时器所需的特定参数信息，格式可按需自行定义，如报表推送的配置格式：\\n  261:营收日报:xxx@xx.com,JK:param1=today-0 \\n \" + \n  \"4、定时器保存并#启用#后，即正式开始执行；停用后自动停止，如需删除，删除前先停用 \\n \" \n); \nforbid(\"description\"); \n!isNew() &&  forbid(\"code\"); \n\n$(\"#name\").blur( genCode );\nfunction genCode() {\n     if( isNew() )  updateField( \"code\",  \"Job-\" + $.now() );\n}\n\npreListener = function() { \n   $(\"#remark\").value(\"\");\n   return true;\n}\n\nafterListener = function() {\n    // 刷新当前的Job池\n    $.post(\"/tss/auth/job/refresh\", {}, function(msg) {\n        $.tssTip( \"定时任务保存成功\" );\n    });\n}',NULL,'','connectionpool','000010000100004','[\n  {\'label\':\'名称\',\'code\':\'name\',\'nullable\':\'false\',\'isparam\':\'true\',\'cwidth\':\'10%\'},\n  {\'label\':\'编码\',\'code\':\'code\',\'type\':\'string\',\'isparam\':\'true\',\'cwidth\':\'8%\'},\n  {\'label\':\'Job执行类\',\'code\':\'jobClassName\',\'width\':\'320\',\'nullable\':\'false\',\'cwidth\':\'120px\'},\n  {\'label\':\'定时策略\',\'code\':\'timeStrategy\',\'nullable\':\'false\',\'defaultValue\':\'0 0 01 * * ?\',\'cwidth\':\'90px\'},\n  {\'label\':\'Job参数\',\'code\':\'customizeInfo\',\'nullable\':\'false\',\'defaultValue\':\'X\',\'width\':\'320\',\'height\':\'64\',\'cwidth\':\'100px\'},\n  {\'label\':\'状态\',\'code\':\'disabled\',\'nullable\':\'false\',\'options\':{\'codes\':\'1|0\',\'names\':\'停用|启用\'},\'width\':\'90\',\'cwidth\':\'30px\'},\n  {\'label\':\'备注\',\'code\':\'remark\',\'height\':\'99\',\'cwidth\':\'60px\',\'width\':\'300\'},\n  {\'label\':\'说明\',\'code\':\'description\',\'height\':\'170\',\'width\':\'350\',\'cwidth\':\'20px\'}\n]',0,3,'系统定时器',0,1,1,'管理系统的定时器配置，定时抽取&推送数据、定时同步用户、定时发布&索引文章等',4,'component_job_def',1,NULL),(6,'2018-04-20 00:26:36',-1,NULL,2,'2018-04-20 00:26:37',-1,NULL,1,'var jobs = {};\n$.getJSON(\"/tss/auth/job\", {}, function(data) { \n  data.each(function(i, item) {\n     jobs[item.id] = item;\n  });\n } , \"GET\");\n\nfunction setJobName(jobId) { \n   var job = jobs[jobId]; \n   job && updateField(\"jobname\",  job.name);\n}\n\n var mi = {\n        label:\"查看执行日志\",\n        callback: function() { showRunLog(); },\n        visible:function() { return true; }\n }\n$1(\"grid\").contextmenu.addItem(mi);\n\nvar etllogReportId = 14;\nfunction showRunLog() {\n     var rowID  = $.G(\"grid\").getColumnValue(\"id\"), \n          name  = $.G(\"grid\").getColumnValue(\"name\");\n     $.openIframePanel(\"etlLogPanel\", \"ETL任务【\" +name+ \"】执行日志\", 1000, 400, \"report_portlet.html?leftBar=true&id=\" +etllogReportId+ \"&refresh=3&param1=today-1&param2=today+1&param3=\" + rowID);\n}','forbid(\"applier,applyday,jobname\");\nif( isNew() ) {\n updateField(\"applyday\", $.now(true) );\n updateField(\"applier\", userName );\n}\nhideFiled(\"jobname\");\n$(\"#manager\").addEvent(\"focus\", function(){ $(this).notice(\"输入管理员的工号\"); } );\n$(\"#sourcescript\").fullscreen();\n\n$(\"#type\").blur( hideF );  hideF();\nfunction hideF() { \n	if( $(\"#type\").value() == \'byID\' || $(\"#type\").value() == \'wsID\') {\n	   hideFiled(\"startday,repeatdays\"); showFiled(\"startid\"); \n	} else {\n	   hideFiled(\"startid\"); showFiled(\"startday,repeatdays\");\n	}\n}',NULL,'','connectionpool','000010000100005','[\n  {\'label\':\'名称\',\'code\':\'name\',\'nullable\':\'false\',\'isparam\':\'true\',\'cwidth\':\'70px\',\'width\':\'200\'},\n  {\'label\':\'类型\',\'code\':\'type\',\'nullable\':\'false\',\'isparam\':\'true\',\'defaultValue\':\'byDay\',\'options\':{\'codes\':\'byDay|byID|wsDay|wsID\',\'names\':\'按天|按ID|ws按天|ws按ID\'},\'width\':\'120\',\'cwidth\':\'25px\'},\n  {\'label\':\'定时器ID\',\'code\':\'jobId\',\'onchange\':\'setJobName\',\'jsonUrl\':\'/tss/auth/job\',\'cwidth\':\'0\'},\n  {\'label\':\'定时器\',\'code\':\'jobname\',\'type\':\'string\',\'cwidth\':\'80px\'},\n  {\'label\':\'优先级\',\'code\':\'priority\',\'type\':\'number\',\'width\':\'120\',\'cwidth\':\'30px\'},\n  {\'label\':\'源数据源\',\'code\':\'sourceDS\',\'nullable\':\'false\',\'jsonUrl\':\'/tss/auth/ds/list\',\'width\':\'180\',\'cwidth\':\'60px\'},\n  {\'label\':\'输入定义\',\'width\':\'350\',\'height\':\'100\',\'code\':\'sourceScript\',\'nullable\':\'false\',\'cwidth\':\'0\'},\n  {\'label\':\'目标数据源\',\'code\':\'targetDS\',\'nullable\':\'false\',\'jsonUrl\':\'/tss/auth/ds/list\',\'width\':\'180\',\'cwidth\':\'60px\'},\n  {\'label\':\'输出定义\',\'code\':\'targetScript\',\'nullable\':\'false\',\'isparam\':\'false\',\'width\':\'350\',\'height\':\'50\',\'cwidth\':\'0\'},\n  {\'label\':\'任务起始ID\',\'type\':\'number\',\'code\':\'startID\',\'width\':\'120\',\'cwidth\':\'30px\'},\n  {\'label\':\'任务起始日期\',\'code\':\'startDay\',\'type\':\'date\',\'cwidth\':\'35px\'},\n  {\'label\':\'重复更新天数\',\'code\':\'repeatDays\',\'type\':\'number\',\'cwidth\':\'30px\'},\n  {\'label\':\'前置操作\',\'code\':\'preRepeatSQL\',\'height\':\'40\',\'width\':\'350\',\'cwidth\':\'0\'},\n  {\'label\':\'任务发起人\',\'code\':\'applier\',\'nullable\':\'false\',\'isparam\':\'true\',\'width\':\'120\'},\n  {\'label\':\'任务发起时间\',\'code\':\'applyDay\',\'type\':\'string\'},\n  {\'label\':\'任务管理员\',\'code\':\'manager\',\'width\':\'320\'},\n  {\'label\':\'任务状态\',\'options\':{\'codes\':\'new|opened|closed\',\'names\':\'new|opened|closed\'},\'code\':\'status\',\'nullable\':\'false\',\'defaultValue\':\'new\',\'cwidth\':\'40px\',\'width\':\'100\'},\n  {\'label\':\'备注\',\'code\':\'remark\',\'height\':\'60\',\'cwidth\':\'0\',\'width\':\'300\'}\n]',0,3,'ETL任务',1,1,1,'etllogReportId=14为报表【ETL_LOG】的ID',5,'dm_etl_task',1,NULL),(7,'2018-04-20 00:26:37',-1,NULL,1,'2018-04-20 00:26:37',-1,NULL,0,NULL,NULL,NULL,NULL,NULL,'0000100002',NULL,0,2,'我的功能',0,0,0,'在此目录下创建你自己的功能数据表吧。open it',2,NULL,0,NULL);
/*!40000 ALTER TABLE `dm_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_record_attach`
--

DROP TABLE IF EXISTS `dm_record_attach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_record_attach` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `fileExt` varchar(255) DEFAULT NULL,
  `fileName` varchar(255) NOT NULL,
  `hitCount` int(11) DEFAULT NULL,
  `itemId` bigint(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `recordId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `uploadDate` datetime DEFAULT NULL,
  `uploadUser` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_record_attach`
--

LOCK TABLES `dm_record_attach` WRITE;
/*!40000 ALTER TABLE `dm_record_attach` DISABLE KEYS */;
/*!40000 ALTER TABLE `dm_record_attach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_report`
--

DROP TABLE IF EXISTS `dm_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_report` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `datasource` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `displayUri` varchar(255) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `mailable` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `needLog` int(11) DEFAULT NULL,
  `param` longtext,
  `paramUri` varchar(255) DEFAULT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `remark` longtext,
  `script` longtext,
  `seqNo` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_report`
--

LOCK TABLES `dm_report` WRITE;
/*!40000 ALTER TABLE `dm_report` DISABLE KEYS */;
INSERT INTO `dm_report` VALUES (1,'2018-04-20 00:26:35',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','0000100001',0,NULL,2,0,'系统报表',1,NULL,NULL,0,NULL,NULL,1,0),(2,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','000010000100001',0,NULL,3,0,'访问统计',1,NULL,NULL,1,NULL,NULL,1,0),(3,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100001',1,NULL,4,0,'GetAllServices',1,NULL,NULL,2,NULL,'SELECT DISTINCT pk, TEXT FROM (\n SELECT methodCnName AS pk, methodCnName AS TEXT, COUNT(*) times FROM dm_access_log WHERE accessTime > DATE_SUB(NOW(),INTERVAL 30 DAY) GROUP BY methodCnName \n) t\nWHERE t.times > 0 ORDER BY t.times DESC',1,1),(4,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100002',1,NULL,4,0,'report_visitors',1,'[\n  {\'label\':\'是否缓存\',\'type\':\'hidden\',\'name\':\'noCache\',\'defaultValue\':\'noCache\'}\n]',NULL,2,NULL,'select distinct u.id as pk, u.userName as text\n from dm_access_log l, um_user u\n where l.userId = u.id\n   and l.accessTime > date_sub(now(),interval 100 day)',2,1),(5,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100003',1,NULL,4,0,'report_list',1,'[{\'label\':\'是否缓存\',\'type\':\'hidden\',\'name\':\'noCache\',\'defaultValue\':\'true\'}]',NULL,2,NULL,'select t.datasource, t.name, t.id, u.userName\n from dm_report t, um_user u\n  where  t.creatorId = u.id\n      and t.datasource is not null\n order by t.datasource',3,1),(6,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100004',1,NULL,4,0,'visit-summary',1,'[ \n   {\'label\':\'访问时间从\', \'type\':\'date\', \'nullable\':\'false\', \'defaultValue\':\'today - 100\'},\n   {\'label\':\'访问时间到\', \'type\':\'date\', \'nullable\':\'true\', \'defaultValue\':\'today + 1\'},\n   {\'label\':\'访问人\'},\n   {\'label\':\'主题\',\'options\':{\'codes\':\'1|2|3\',\'names\':\'数据服务|数据操作|ETL\'},\'defaultValue\':\'1\'}\n]',NULL,2,NULL,'<#if param4=\'1\'>\nselect methodCnName f1,  ROUND(avg(runningTime/1000), 1)  f2, ROUND(max(runningTime/1000), 1) f3, \n          count(*)  f4, sum( case when runningTime>5000 then 1 else 0 end)  f5\n from dm_access_log l, um_user u\n where   l.userId = u.id\n      and l.accessTime >= ? <#if param2??> and l.accessTime < ?  </#if>\n      <#if param3??> and ( u.loginName in (${param3}) or u.userName in (${param3}) ) </#if>\n group by methodCnName\n order by f2 desc\n\n<#elseif param4=\'2\'>\nSELECT operateTable  f1,  count(*)  f2, count(distinct operatorId) f3,  null f4, null f5\n FROM  component_log l, um_user u\n where l.operatorId = u.id\n    and l.operateTime >= ? <#if param2??> and l.operateTime < ?  </#if>\n    <#if param3??> and ( u.loginName in (${param3}) or u.userName in (${param3}) ) </#if>\n  group by operateTable\n order by f1 desc\n\n<#elseif param4=\'3\'>\nSELECT max(taskName)  f1, count(*)  f2, round(avg(runningMS)/1000, 1)  f3, round(max(runningMS/1000), 1) f4,\n	 round(avg( substring(detail, position(\'=\' in detail)+1) )) f5\nFROM dm_etl_task_log l\nwhere exception=\'no\'  and detail like \'%total=%\' \n    and l.excuteTime >= ? <#if param2??> and l.excuteTime < ?  </#if> <#if param3??>  </#if>\ngroup by taskId\n order by f3 desc\n\n</#if>',4,1),(7,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100005',1,NULL,4,0,'visit-trace',1,'[ \n  {\'label\':\'服务名称\', \'type\':\'String\', \'nullable\':\'true\', \'jsonUrl\':\'../../api/json/GetAllServices\',\'multiple\':\'true\', \'height\':\'200px\'},\n  {\'label\':\'访问人\'},\n  {\'label\':\'访问时间从\', \'type\':\'date\', \'nullable\':\'false\', \'defaultValue\':\'today - 0\'} ,\n  {\'label\':\'访问时间到\', \'type\':\'date\', \'nullable\':\'true\', \'defaultValue\':\'today + 1\'},\n  {\'label\':\'主题\',\'options\':{\'codes\':\'1|2|3\',\'names\':\'数据服务|数据操作|ETL\'},\'defaultValue\':\'1\'}\n]',NULL,2,NULL,'<#if param5=\'1\'>\nselect methodCnName 服务名称, methodName 方法, className 所属类,  params 参数, accessTime 访问时间, runningTime 运行时长, userName 访问人\nfrom (\n select methodCnName,methodName,className,replace(replace(params,\'\\\"\',\'\\\'\'),\',\',\' \') params,accessTime,runningTime,u.userName  \n  from dm_access_log l, um_user u\n  where l.userId = u.id\n   <#if param1??> and l.methodCnName in (${param1}) </#if>\n   <#if param2??> and ( u.loginName in (${param2}) or u.userName in (${param2}) ) </#if>\n   and l.accessTime > ? <#if param4??> and l.accessTime < ?  </#if>\n) as t\norder by 运行时长 desc\n\n<#elseif param5=\'2\'>\nselect operateTable 操作对象, operatorName 操作人, substring(content, 1, 100) 操作内容, operateTime 操作时间, operatorBrowser 浏览器, operatorIP ip\n from component_log l\nwhere 1=1\n   <#if param1??> and l.operateTable in (${param1}) </#if>\n   <#if param2??> and l.operatorName in (${param2}) </#if>\n   and l.operatetime >= ? <#if param4??> and l.operatetime < ?  </#if>\n   and l.operateTable not in (\'用户登录\') \norder by operateTime desc\n\n<#elseif param5=\'3\'>\nSELECT applier 创建人, t.name 任务,  jobName 定时器, count(*)  异常次数,  GROUP_CONCAT(distinct detail, \' \') 异常原因, \n    Round(max(runningMS/1000),1) 耗时, min(excuteTime) 最早一次出错, max(excuteTime) 最近一次出错\nFROM dm_etl_task_log l, dm_etl_task t \nwhere l.taskId = t.id and exception = \'yes\'\n  <#if param1??> and  t.name in (${param1}) </#if>\n  <#if param2??> and t.applier in (${param2}) </#if>\n  and l.excuteTime >= ? <#if param4??> and l.excuteTime < ?  </#if>\ngroup by t.name\norder by 创建人, 异常次数 desc\n\n</#if>',5,1),(8,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100006',1,'../../more/bi_template/ichart.html?type=Line2D',4,0,'visit-trend',1,'[\n  {\'label\':\'服务名称\',\'type\':\'String\',\'nullable\':\'true\',\'jsonUrl\':\'../../api/json/GetAllServices\',\'multiple\':\'false\',\'height\':\'200px\'},\n  {\'label\':\'访问人\'},\n  {\'label\':\'访问时间从\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today - 30\'},\n  {\'label\':\'访问时间到\',\'type\':\'date\',\'nullable\':\'true\',\'defaultValue\':\'today +1\'},\n  {\'label\':\'按\',\'options\':{\'codes\':\'d|H\',\'names\':\'日期|小时\'},\'defaultValue\':\'H\',\'nullable\':\'false\'},\n  {\'label\':\'主题\',\'options\':{\'codes\':\'1|2|3\',\'names\':\'数据服务|数据操作|ETL\'},\'defaultValue\':\'1\'}\n]',NULL,2,NULL,'<#if param6=\'1\'>\nselect  date_format(accessTime, <#if param5=\'d\'>\'%m-%d\'<#else>\'%H\'</#if>)  name,  \n            ROUND(avg(runningTime)) value, count(*)  v2, count(distinct l.userId) 访问人数\n   from dm_access_log l, um_user u\n   where l.userId = u.id\n    <#if param1??> and l.methodCnName in (${param1}) </#if>\n    <#if param2??> and ( u.loginName in (${param2}) or u.userName in (${param2}) ) </#if>\n    and l.accessTime > ? <#if param4??> and l.accessTime < ?  </#if>\n  group by  date_format(accessTime, <#if param5=\'d\'>\'%m-%d\'<#else>\'%H\'</#if>) \n\n<#elseif param6=\'2\'>\nselect date_format(operatetime, <#if param5=\'d\'>\'%m-%d\'<#else>\'%H\'</#if>)  name, count(distinct operatorId) value, count(*)  v2\n  from component_log l\n  where 1=1\n    <#if param1??> and l.operateTable in (${param1}) </#if>\n    <#if param2??> and l.operatorName in (${param2}) </#if>\n    and l.operatetime >= ? <#if param4??> and l.operatetime < ?  </#if>\n  group by  date_format(operatetime, <#if param5=\'d\'>\'%m-%d\'<#else>\'%H\'</#if>) \n\n<#elseif param6=\'3\'>\nSELECT  date_format(excuteTime, <#if param5=\'d\'>\'%m-%d\'<#else>\'%H\'</#if>)  name, \n     round(avg(runningMS)) value,  sum( substring(detail, position(\'=\' in detail)+1) )  v2\n  FROM dm_etl_task_log l, dm_etl_task t \n  where l.taskId = t.id and exception = \'no\' and l.detail like \'%total=%\' \n    <#if param1??> and  t.name in (${param1}) </#if>\n    <#if param2??> and t.applier in (${param2}) </#if>\n    and l.excuteTime >= ? <#if param4??> and l.excuteTime < ?  </#if>\n  group by  date_format(excuteTime, <#if param5=\'d\'>\'%m-%d\'<#else>\'%H\'</#if>) \n\n</#if>\n order by name asc',6,1),(9,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100007',0,NULL,4,0,'统计用户访问情况',1,'[\n  {\'label\':\'访问人\',\'type\':\'String\',\'nullable\':\'true\'},\n  {\'label\':\'访问时间从\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today - 30\'},\n  {\'label\':\'访问时间到\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today + 1\'}\n]',NULL,2,NULL,'select userName 访问人, methodCnName 服务名称, methodName 方法, \n     min(accessTime) 第一次访问时间, max(accessTime) 最后访问时间, count(*) 访问次数 \n  from dm_access_log l, um_user u\n  where l.userId = u.id \n    <#if param1??> and u.userName in (${param1}) </#if>\n    and l.accessTime >= ?\n    and l.accessTime < ?\n  group by userName, methodCnName, methodName\n order by 访问人',7,1),(10,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100008',0,'../../more/bi_template/ichart.html?type=Pie3D',4,0,'统计服务访问占比',1,'[ \n  {\'label\':\'起始时间\', \'type\':\'date\', \'nullable\':\'false\', \'defaultValue\':\'today - 30\'}, \n  {\'label\':\'结束时间\', \'type\':\'date\', \'nullable\':\'false\', \'defaultValue\':\'today + 0\'}\n]',NULL,2,'../../more/bi_template/ichart.html?type=Bar2D','select methodCnName name, count(*) value\n from dm_access_log l \n where 0 = 0\n   and l.accessTime >= ?\n   and l.accessTime <= ?\n   and l.methodCnName not like \'Get%\'\n group by methodCnName  \n order by value desc',8,1),(11,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100009',0,'../../more/bi_template/ichart.html?type=Column2D',4,0,'统计新增资源数',1,'[\n  {\'label\':\'按\',\'options\':{\'codes\':\'1|2\',\'names\':\'按开发者|按月份\'},\'defaultValue\':\'2\'},\n  {\'label\':\'类型\',\'options\':{\'codes\':\'dm_report|dm_record|cms_article|um_user\',\'names\':\'数据报表|数据录入|文章|用户\'},\'defaultValue\':\'dm_report\'},\n  {\'label\':\'创建时间从\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today - 365\'},\n  {\'label\':\'创建时间到\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today + 1\'}\n]',NULL,2,'统计新增 报表/录入/文章/用户','<#if param1=\'1\'>\n  select u.userName as name, count(*) as value, count(distinct t.creatorId) v2 \n  from ${param2}  t, um_user u \n  where t.creatorId = u.id \n     and t.createTime >= ? and t.createTime <= ?\n  group by u.userName\n<#else>\n  select DATE_FORMAT(t.createTime,\'%Y%m\') as name, count(*) as value,  count(distinct t.creatorId) v2 \n  from ${param2}  t \n  where t.createTime >= ? and t.createTime <= ?\n  group by DATE_FORMAT(t.createTime,\'%Y%m\')\n</#if>',9,1),(12,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100010',0,NULL,4,0,'统计用户登录',1,'[\n  {\'label\':\'起始时间\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today-30\'},\n  {\'label\':\'结束时间\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today+1\'},\n   {\'label\':\'统计方式\',\'options\':{\'codes\':\'1|2\',\'names\':\'按日|按用户\'},\'defaultValue\':\'1\'}\n]',NULL,2,'../../more/bi_template/ichart.html?type=Line2D','<#if param3=\'1\'>\nselect  date_format(operateTime, \'%Y-%m-%d\')   name,  count(distinct operationCode)  value, count(*) v2\nfrom component_log t\nwhere t.operateTable = \'用户登录\' and t.operateTime >= ?  and t.operateTime < ?\ngroup by  date_format(operateTime, \'%Y-%m-%d\')  \norder by  name\n<#else>\nselect t.operationCode 登录人, t.operatorName 登录账号, count(*) 登录次数\nfrom component_log t\nwhere t.operateTable = \'用户登录\' and t.operateTime >= ?  and t.operateTime < ?\ngroup by t.operationCode, t.operatorName\norder by 登录次数 desc\n</#if>',10,1),(13,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100011',1,'../../more/x/feedback.html',4,0,'queryFeedback',1,'[\n{\'label\':\'不要缓存\',\'type\':\'hidden\',\'name\':\'noCache\',\'defaultValue\':\'true\'}\n]',NULL,2,NULL,'SELECT t.id, t.content, t.module, t.type, t.createTime, u.userName, t.commiter, t.state, t.processing, t.processor, t.updateTime, t.updator\nFROM x_feedback t, um_user u\nwhere t.creator = u.loginName\norder by t.id desc',11,1),(14,'2018-04-20 00:26:36',-1,NULL,1,'2018-04-20 00:26:36',-1,NULL,'connectionpool','00001000010000100012',1,NULL,4,0,'ETL_LOG',0,'[\n  {\'label\':\'访问时间从\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today - 3\'},\n  {\'label\':\'访问时间到\',\'type\':\'date\',\'nullable\':\'false\',\'defaultValue\':\'today + 1\'},\n  {\'label\':\'任务\',\'type\':\'string\',\'nullable\':\'true\',\'jsonUrl\':\'/tss/auth/xdata/json/6/1\'},\n  {\'label\':\'是否缓存\',\'type\':\'hidden\',\'name\':\'noCache\',\'defaultValue\':\'true\'}\n]','no-need',2,'4为录入表【ELT任务】的ID','select taskName 任务名称, excuteTime 结束时间, runningMS 耗时, exception 是否异常, detail 详情,  IFNULL(dataDay, maxID) 参数信息\n from dm_etl_task_log \n where 1=1\n     and excuteTime >= ? and excuteTime <= ?\n     <#if param3??> and taskId = ? </#if>\norder by id desc',12,1),(15,'2018-04-20 00:26:37',-1,NULL,1,'2018-04-20 00:26:37',-1,NULL,NULL,'0000100002',0,NULL,2,0,'我的报表',1,NULL,NULL,0,'在此目录下创建你自己的报表吧。open it',NULL,2,0);
/*!40000 ALTER TABLE `dm_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dm_report_user`
--

DROP TABLE IF EXISTS `dm_report_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dm_report_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `reportId` bigint(20) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `userId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dm_report_user`
--

LOCK TABLES `dm_report_user` WRITE;
/*!40000 ALTER TABLE `dm_report_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `dm_report_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `online_user`
--

DROP TABLE IF EXISTS `online_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `online_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appCode` varchar(255) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  `clientIp` varchar(255) DEFAULT NULL,
  `loginTime` datetime DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `online_user`
--

LOCK TABLES `online_user` WRITE;
/*!40000 ALTER TABLE `online_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `online_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_component`
--

DROP TABLE IF EXISTS `portal_component`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_component` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `definition` longtext,
  `description` longtext,
  `disabled` int(11) DEFAULT NULL,
  `isDefault` int(11) DEFAULT NULL,
  `isGroup` bit(1) NOT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `parentId` bigint(20) NOT NULL,
  `portNumber` int(11) NOT NULL,
  `seqNo` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parentId` (`parentId`,`type`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_component`
--

LOCK TABLES `portal_component` WRITE;
/*!40000 ALTER TABLE `portal_component` DISABLE KEYS */;
INSERT INTO `portal_component` VALUES (1,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'00001',NULL,NULL,0,0,'',1,'布局器组',0,0,1,1,NULL),(2,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'0000100001','<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<layout>\n	<property>\n		<name>默认布局器</name>\n		<portNumber>-1</portNumber>\n	</property>\n	<html>\n		<![CDATA[\n			<table id=\"${id}\">\n				<tr>\n					<td>${port0}</td>\n				</tr>\n			</table>\n		]]>\n	</html>\n</layout>',NULL,0,1,'\0',2,'默认布局器',1,-1,1,1,NULL),(3,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'00002',NULL,NULL,0,0,'',1,'修饰器组',0,0,2,2,NULL),(4,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'0000200001','<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<decorator>\n	<property>\n		<name>默认修饰器</name>\n	</property>\n	<script><![CDATA[]]></script>\n	<style><![CDATA[]]></style>\n	<html>\n		<![CDATA[<table id=${id} class=\"decorator\">\n		  <tbody>\n			<tr>\n			  <td>\n				${content}\n			  </td>\n			</tr>\n		  </tbody>\n		</table>]]>\n	</html>\n	<events/>\n	<parameters/>\n</decorator>',NULL,0,1,'\0',2,'默认修饰器',3,0,1,2,NULL),(5,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'00003',NULL,NULL,0,0,'',1,'portlet组',0,0,3,3,NULL);
/*!40000 ALTER TABLE `portal_component` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_flowrate`
--

DROP TABLE IF EXISTS `portal_flowrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_flowrate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL,
  `pageId` bigint(20) DEFAULT NULL,
  `visitTime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_flowrate`
--

LOCK TABLES `portal_flowrate` WRITE;
/*!40000 ALTER TABLE `portal_flowrate` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_flowrate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_navigator`
--

DROP TABLE IF EXISTS `portal_navigator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_navigator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `description` longtext,
  `disabled` int(11) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `methodName` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `portalId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) NOT NULL,
  `target` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `content_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parentId` (`parentId`,`name`),
  KEY `FKDD02164418ACE62E` (`content_id`),
  CONSTRAINT `FKDD02164418ACE62E` FOREIGN KEY (`content_id`) REFERENCES `portal_structure` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_navigator`
--

LOCK TABLES `portal_navigator` WRITE;
/*!40000 ALTER TABLE `portal_navigator` DISABLE KEYS */;
INSERT INTO `portal_navigator` VALUES (1,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,NULL,'0000100001',NULL,0,2,NULL,'应用菜单组',NULL,0,NULL,1,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `portal_navigator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_permission_navigator`
--

DROP TABLE IF EXISTS `portal_permission_navigator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_permission_navigator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_permission_navigator`
--

LOCK TABLES `portal_permission_navigator` WRITE;
/*!40000 ALTER TABLE `portal_permission_navigator` DISABLE KEYS */;
INSERT INTO `portal_permission_navigator` VALUES (1,1,1,'1',2,0,'root',-1),(2,1,1,'2',2,0,'root',-1),(3,1,1,'1',2,1,'应用菜单组',-1),(4,1,1,'2',2,1,'应用菜单组',-1);
/*!40000 ALTER TABLE `portal_permission_navigator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_permission_portal`
--

DROP TABLE IF EXISTS `portal_permission_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_permission_portal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_permission_portal`
--

LOCK TABLES `portal_permission_portal` WRITE;
/*!40000 ALTER TABLE `portal_permission_portal` DISABLE KEYS */;
INSERT INTO `portal_permission_portal` VALUES (1,1,1,'1',2,0,'root',-1),(2,1,1,'2',2,0,'root',-1),(3,1,1,'3',2,0,'root',-1),(4,1,1,'4',2,0,'root',-1),(5,1,1,'5',2,0,'root',-1),(6,1,1,'6',2,0,'root',-1),(7,1,1,'7',2,0,'root',-1);
/*!40000 ALTER TABLE `portal_permission_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_release_config`
--

DROP TABLE IF EXISTS `portal_release_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_release_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `visitUrl` varchar(255) NOT NULL,
  `page_id` bigint(20) DEFAULT NULL,
  `portal_id` bigint(20) DEFAULT NULL,
  `theme_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `FKCF1E12AD636CC834` (`theme_id`),
  KEY `FKCF1E12AD4B7D295B` (`portal_id`),
  KEY `FKCF1E12ADD902F858` (`page_id`),
  CONSTRAINT `FKCF1E12ADD902F858` FOREIGN KEY (`page_id`) REFERENCES `portal_structure` (`id`),
  CONSTRAINT `FKCF1E12AD4B7D295B` FOREIGN KEY (`portal_id`) REFERENCES `portal_structure` (`id`),
  CONSTRAINT `FKCF1E12AD636CC834` FOREIGN KEY (`theme_id`) REFERENCES `portal_theme` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_release_config`
--

LOCK TABLES `portal_release_config` WRITE;
/*!40000 ALTER TABLE `portal_release_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_release_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_structure`
--

DROP TABLE IF EXISTS `portal_structure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_structure` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `parameters` longtext,
  `parentId` bigint(20) NOT NULL,
  `portalId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) NOT NULL,
  `supplement` longtext,
  `type` int(11) NOT NULL,
  `currentTheme_id` bigint(20) DEFAULT NULL,
  `definer_id` bigint(20) DEFAULT NULL,
  `theme_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parentId` (`parentId`,`name`),
  KEY `FKB8C019607029DF5A` (`definer_id`),
  KEY `FKB8C01960636CC834` (`theme_id`),
  KEY `FKB8C01960E5E3FCAD` (`currentTheme_id`),
  CONSTRAINT `FKB8C01960E5E3FCAD` FOREIGN KEY (`currentTheme_id`) REFERENCES `portal_theme` (`id`),
  CONSTRAINT `FKB8C01960636CC834` FOREIGN KEY (`theme_id`) REFERENCES `portal_theme` (`id`),
  CONSTRAINT `FKB8C019607029DF5A` FOREIGN KEY (`definer_id`) REFERENCES `portal_component` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_structure`
--

LOCK TABLES `portal_structure` WRITE;
/*!40000 ALTER TABLE `portal_structure` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_structure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_theme`
--

DROP TABLE IF EXISTS `portal_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_theme` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `portalId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `portalId` (`portalId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_theme`
--

LOCK TABLES `portal_theme` WRITE;
/*!40000 ALTER TABLE `portal_theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_theme_info`
--

DROP TABLE IF EXISTS `portal_theme_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_theme_info` (
  `structureId` bigint(20) NOT NULL,
  `themeId` bigint(20) NOT NULL,
  `parameters` longtext,
  `decorator_id` bigint(20) DEFAULT NULL,
  `layout_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`structureId`,`themeId`),
  KEY `FK74F26F175AEDC567` (`layout_id`),
  KEY `FK74F26F17485222B6` (`decorator_id`),
  CONSTRAINT `FK74F26F17485222B6` FOREIGN KEY (`decorator_id`) REFERENCES `portal_component` (`id`),
  CONSTRAINT `FK74F26F175AEDC567` FOREIGN KEY (`layout_id`) REFERENCES `portal_component` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_theme_info`
--

LOCK TABLES `portal_theme_info` WRITE;
/*!40000 ALTER TABLE `portal_theme_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_theme_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_theme_personal`
--

DROP TABLE IF EXISTS `portal_theme_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portal_theme_personal` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `portalId` bigint(20) DEFAULT NULL,
  `themeId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_theme_personal`
--

LOCK TABLES `portal_theme_personal` WRITE;
/*!40000 ALTER TABLE `portal_theme_personal` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_theme_personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_application`
--

DROP TABLE IF EXISTS `um_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_application` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `applicationId` varchar(50) NOT NULL,
  `applicationType` varchar(10) DEFAULT NULL,
  `dataSourceType` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `paramDesc` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `applicationId` (`applicationId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_application`
--

LOCK TABLES `um_application` WRITE;
/*!40000 ALTER TABLE `um_application` DISABLE KEYS */;
INSERT INTO `um_application` VALUES (1,'2018-04-20 00:26:35',-1,NULL,0,NULL,NULL,NULL,'tss','-1',NULL,NULL,'TSS',NULL);
/*!40000 ALTER TABLE `um_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_group`
--

DROP TABLE IF EXISTS `um_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `fromApp` varchar(255) DEFAULT NULL,
  `fromGroupId` varchar(255) DEFAULT NULL,
  `groupType` int(11) NOT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parentId` (`parentId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_group`
--

LOCK TABLES `um_group` WRITE;
/*!40000 ALTER TABLE `um_group` DISABLE KEYS */;
INSERT INTO `um_group` VALUES (-9,NULL,NULL,NULL,0,NULL,NULL,NULL,'000010000100003',NULL,0,'开发者域',NULL,NULL,1,3,'$开发者域',-2,3),(-8,NULL,NULL,NULL,0,NULL,NULL,NULL,'000010000100002','open it',0,'企业域',NULL,NULL,1,3,'$企业域',-2,2),(-7,NULL,NULL,NULL,0,NULL,NULL,NULL,'000010000100001',NULL,0,'自注册域',NULL,NULL,1,3,'$自注册域',-2,1),(-3,NULL,NULL,NULL,0,NULL,NULL,NULL,'0000100002',NULL,0,NULL,NULL,NULL,2,2,'辅助用户组',-1,2),(-2,NULL,NULL,NULL,0,NULL,NULL,NULL,'0000100001',NULL,0,NULL,NULL,NULL,1,2,'主用户组',-1,1),(-1,NULL,NULL,NULL,0,NULL,NULL,NULL,'00001',NULL,0,NULL,NULL,NULL,0,1,'root',0,1);
/*!40000 ALTER TABLE `um_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_groupuser`
--

DROP TABLE IF EXISTS `um_groupuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_groupuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `groupId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupId` (`groupId`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_groupuser`
--

LOCK TABLES `um_groupuser` WRITE;
/*!40000 ALTER TABLE `um_groupuser` DISABLE KEYS */;
INSERT INTO `um_groupuser` VALUES (-2,-2,-10000),(-3,-2,-997),(-1,-2,-1);
/*!40000 ALTER TABLE `um_groupuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_message`
--

DROP TABLE IF EXISTS `um_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `readTime` datetime DEFAULT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `receiverId` bigint(20) DEFAULT NULL,
  `sendTime` datetime DEFAULT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `senderId` bigint(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_message`
--

LOCK TABLES `um_message` WRITE;
/*!40000 ALTER TABLE `um_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `um_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_operation`
--

DROP TABLE IF EXISTS `um_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_operation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `applicationId` varchar(50) NOT NULL,
  `dependId` varchar(255) DEFAULT NULL,
  `dependParent` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `operationId` varchar(50) NOT NULL,
  `resourceTypeId` varchar(50) NOT NULL,
  `seqNo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `applicationId` (`applicationId`,`resourceTypeId`,`operationId`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_operation`
--

LOCK TABLES `um_operation` WRITE;
/*!40000 ALTER TABLE `um_operation` DISABLE KEYS */;
INSERT INTO `um_operation` VALUES (1,'tss',NULL,'2',NULL,'查看','1','1',1),(2,'tss','opt1',NULL,NULL,'管理','2','1',2),(3,'tss',NULL,'2',NULL,'查看','1','2',1),(4,'tss','opt1',NULL,NULL,'管理','2','2',2),(5,'tss',NULL,'2',NULL,'查看浏览','1','3',1),(6,'tss','opt1',NULL,NULL,'新建栏目','2','3',2),(7,'tss','opt1',NULL,NULL,'新建文章','3','3',3),(8,'tss','opt1','3',NULL,'发布文章','4','3',4),(9,'tss','opt1',NULL,NULL,'编辑权限','5','3',5),(10,'tss','opt1','3',NULL,'删除权限','6','3',6),(11,'tss','opt1','2,3',NULL,'停用启用','7','3',7),(12,'tss','opt1',NULL,NULL,'排序权限','8','3',8),(13,'tss','opt1',NULL,NULL,'移动权限','9','3',9),(14,'tss',NULL,'2','查看门户结构','查看','1','4',1),(15,'tss','opt1',NULL,'编辑门户结构','编辑','2','4',2),(16,'tss','opt1','3','删除门户结构','删除','3','4',3),(17,'tss','opt1',NULL,'增加门户结构','增加','4','4',4),(18,'tss','opt1',NULL,'排序门户结构','排序','5','4',5),(19,'tss','opt1','3','停用门户结构','停用','6','4',6),(20,'tss','opt1','2','启用门户结构','启用','7','4',7),(21,'tss',NULL,'2','浏览','浏览','1','5',1),(22,'tss',NULL,NULL,'维护','维护','2','5',2),(23,'tss',NULL,'2',NULL,'查看报表','1','D1',1),(24,'tss','opt1',NULL,NULL,'维护报表','2','D1',2),(25,'tss','opt1','3',NULL,'删除报表','3','D1',3),(26,'tss','opt1','2,3',NULL,'停用启用','4','D1',4),(27,'tss',NULL,'2',NULL,'录入数据','1','D2',3),(28,'tss','opt1',NULL,NULL,'定义数据表','2','D2',1),(29,'tss','opt1','3',NULL,'删除数据表','3','D2',2),(30,'tss',NULL,NULL,NULL,'浏览数据','4','D2',4),(31,'tss','opt4',NULL,NULL,'维护数据','5','D2',5);
/*!40000 ALTER TABLE `um_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_permission_group`
--

DROP TABLE IF EXISTS `um_permission_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_permission_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_permission_group`
--

LOCK TABLES `um_permission_group` WRITE;
/*!40000 ALTER TABLE `um_permission_group` DISABLE KEYS */;
INSERT INTO `um_permission_group` VALUES (1,1,1,'1',2,-1,'root',-1),(2,1,1,'1',2,-2,'主用户组',-1),(3,1,1,'1',2,-7,'$自注册域',-1),(4,1,1,'1',2,-8,'$企业域',-1),(5,1,1,'1',2,-9,'$开发者域',-1),(6,1,1,'1',2,-3,'辅助用户组',-1),(7,1,1,'2',2,-1,'root',-1),(8,1,1,'2',2,-2,'主用户组',-1),(9,1,1,'2',2,-7,'$自注册域',-1),(10,1,1,'2',2,-8,'$企业域',-1),(11,1,1,'2',2,-9,'$开发者域',-1),(12,1,1,'2',2,-3,'辅助用户组',-1),(13,1,1,'1',2,-2,'主用户组',-1),(14,1,1,'2',2,-2,'主用户组',-1),(15,1,1,'1',2,-3,'辅助用户组',-1),(16,1,1,'2',2,-3,'辅助用户组',-1),(17,1,1,'1',2,-7,'$自注册域',-1),(18,1,1,'2',2,-7,'$自注册域',-1),(19,1,1,'1',2,-7,'$自注册域',-1),(20,1,1,'2',2,-7,'$自注册域',-1),(21,1,1,'1',2,-8,'$企业域',-1),(22,1,1,'2',2,-8,'$企业域',-1),(23,1,1,'1',2,-8,'$企业域',-1),(24,1,1,'2',2,-8,'$企业域',-1),(25,1,1,'1',2,-9,'$开发者域',-1),(26,1,1,'2',2,-9,'$开发者域',-1),(27,1,1,'1',2,-9,'$开发者域',-1),(28,1,1,'2',2,-9,'$开发者域',-1),(29,0,0,'2',2,-8,'$企业域',-8),(30,0,0,'1',2,-8,'$企业域',-8);
/*!40000 ALTER TABLE `um_permission_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_permission_role`
--

DROP TABLE IF EXISTS `um_permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_permission_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `isGrant` int(11) DEFAULT NULL,
  `isPass` int(11) DEFAULT NULL,
  `operationId` varchar(255) NOT NULL,
  `permissionState` int(11) DEFAULT NULL,
  `resourceId` bigint(20) NOT NULL,
  `resourceName` varchar(255) DEFAULT NULL,
  `roleId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_permission_role`
--

LOCK TABLES `um_permission_role` WRITE;
/*!40000 ALTER TABLE `um_permission_role` DISABLE KEYS */;
INSERT INTO `um_permission_role` VALUES (1,1,1,'1',2,-6,'全部',-1),(2,1,1,'1',2,-1,'系统管理员',-1),(3,1,1,'1',2,-10000,'$匿名角色',-1),(4,1,1,'1',2,-8,'$域管理员',-1),(5,1,1,'1',2,-9,'$开发者',-1),(6,1,1,'2',2,-6,'全部',-1),(7,1,1,'2',2,-1,'系统管理员',-1),(8,1,1,'2',2,-10000,'$匿名角色',-1),(9,1,1,'2',2,-8,'$域管理员',-1),(10,1,1,'2',2,-9,'$开发者',-1);
/*!40000 ALTER TABLE `um_permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_resourcetype`
--

DROP TABLE IF EXISTS `um_resourcetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_resourcetype` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `applicationId` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `permissionTable` varchar(255) NOT NULL,
  `resourceTable` varchar(255) NOT NULL,
  `resourceTypeId` varchar(50) NOT NULL,
  `rootId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `applicationId` (`applicationId`,`resourceTypeId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_resourcetype`
--

LOCK TABLES `um_resourcetype` WRITE;
/*!40000 ALTER TABLE `um_resourcetype` DISABLE KEYS */;
INSERT INTO `um_resourcetype` VALUES (1,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','用户组织资源','用户组','com.boubei.tss.um.entity.permission.GroupPermission','com.boubei.tss.um.entity.permission.GroupResource','1',-1,1),(2,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','角色资源','角色','com.boubei.tss.um.entity.permission.RolePermission','com.boubei.tss.um.entity.permission.RoleResource','2',-6,2),(3,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','内容栏目资源','内容栏目','com.boubei.tss.cms.entity.permission.ChannelPermission','com.boubei.tss.cms.entity.permission.ChannelResource','3',-1,3),(4,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','门户结构资源','门户结构','com.boubei.tss.portal.entity.permission.PortalPermission','com.boubei.tss.portal.entity.permission.PortalResource','4',0,4),(5,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','菜单导航资源','菜单导航','com.boubei.tss.portal.entity.permission.NavigatorPermission','com.boubei.tss.portal.entity.permission.NavigatorResource','5',0,5),(6,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','数据报表资源','数据报表','com.boubei.tss.dm.report.permission.ReportPermission','com.boubei.tss.dm.report.permission.ReportResource','D1',0,21),(7,'2018-04-20 00:26:34',-1,NULL,0,NULL,NULL,NULL,'tss','数据表资源','数据表','com.boubei.tss.dm.record.permission.RecordPermission','com.boubei.tss.dm.record.permission.RecordResource','D2',0,22);
/*!40000 ALTER TABLE `um_resourcetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_resourcetype_root`
--

DROP TABLE IF EXISTS `um_resourcetype_root`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_resourcetype_root` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `applicationId` varchar(255) DEFAULT NULL,
  `resourceTypeId` varchar(255) DEFAULT NULL,
  `rootId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_resourcetype_root`
--

LOCK TABLES `um_resourcetype_root` WRITE;
/*!40000 ALTER TABLE `um_resourcetype_root` DISABLE KEYS */;
INSERT INTO `um_resourcetype_root` VALUES (1,'tss','1',-1),(2,'tss','2',-6),(3,'tss','3',-1),(4,'tss','4',0),(5,'tss','5',0),(6,'tss','D1',0),(7,'tss','D2',0);
/*!40000 ALTER TABLE `um_resourcetype_root` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_role`
--

DROP TABLE IF EXISTS `um_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `decode` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `isGroup` int(11) DEFAULT NULL,
  `levelNo` int(11) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `parentId` bigint(20) DEFAULT NULL,
  `seqNo` int(11) DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `parentId` (`parentId`,`name`,`isGroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_role`
--

LOCK TABLES `um_role` WRITE;
/*!40000 ALTER TABLE `um_role` DISABLE KEYS */;
INSERT INTO `um_role` VALUES (-10000,NULL,NULL,NULL,0,NULL,NULL,NULL,'0000100002',NULL,0,'2099-01-01 00:00:00',0,2,'$匿名角色',-6,2,'2018-04-20 00:26:34'),(-9,NULL,NULL,NULL,0,NULL,NULL,NULL,'0000100004',NULL,0,'2099-01-01 00:00:00',0,2,'$开发者',-6,4,'2018-04-20 00:26:34'),(-8,NULL,NULL,NULL,0,NULL,NULL,NULL,'0000100003',NULL,0,'2099-01-01 00:00:00',0,2,'$域管理员',-6,3,'2018-04-20 00:26:34'),(-6,NULL,NULL,NULL,0,NULL,NULL,NULL,'00001',NULL,0,NULL,1,1,'全部',0,1,NULL),(-1,NULL,NULL,NULL,0,NULL,NULL,NULL,'0000100001',NULL,0,'2099-01-01 00:00:00',0,2,'系统管理员',-6,1,'2018-04-20 00:26:34');
/*!40000 ALTER TABLE `um_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_rolegroup`
--

DROP TABLE IF EXISTS `um_rolegroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_rolegroup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `groupId` bigint(20) DEFAULT NULL,
  `roleId` bigint(20) DEFAULT NULL,
  `strategyId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roleId` (`roleId`,`groupId`,`strategyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_rolegroup`
--

LOCK TABLES `um_rolegroup` WRITE;
/*!40000 ALTER TABLE `um_rolegroup` DISABLE KEYS */;
INSERT INTO `um_rolegroup` VALUES (-1,-9,-9,NULL),(-2,-7,-8,NULL);
/*!40000 ALTER TABLE `um_rolegroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_roleuser`
--

DROP TABLE IF EXISTS `um_roleuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_roleuser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `roleId` bigint(20) DEFAULT NULL,
  `strategyId` bigint(20) DEFAULT NULL,
  `userId` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roleId` (`roleId`,`userId`,`strategyId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_roleuser`
--

LOCK TABLES `um_roleuser` WRITE;
/*!40000 ALTER TABLE `um_roleuser` DISABLE KEYS */;
INSERT INTO `um_roleuser` VALUES (2,-1,NULL,-997),(1,-1,NULL,-1);
/*!40000 ALTER TABLE `um_roleuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_roleusermapping`
--

DROP TABLE IF EXISTS `um_roleusermapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_roleusermapping` (
  `roleId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  PRIMARY KEY (`roleId`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_roleusermapping`
--

LOCK TABLES `um_roleusermapping` WRITE;
/*!40000 ALTER TABLE `um_roleusermapping` DISABLE KEYS */;
INSERT INTO `um_roleusermapping` VALUES (-10000,-10000),(-10000,-1),(-1,-1);
/*!40000 ALTER TABLE `um_roleusermapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_sub_authorize`
--

DROP TABLE IF EXISTS `um_sub_authorize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_sub_authorize` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `description` longtext,
  `disabled` int(11) DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `startDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_sub_authorize`
--

LOCK TABLES `um_sub_authorize` WRITE;
/*!40000 ALTER TABLE `um_sub_authorize` DISABLE KEYS */;
/*!40000 ALTER TABLE `um_sub_authorize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_user`
--

DROP TABLE IF EXISTS `um_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creatorId` bigint(20) DEFAULT NULL,
  `creatorName` varchar(255) DEFAULT NULL,
  `lockVersion` int(11) NOT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updatorId` bigint(20) DEFAULT NULL,
  `updatorName` varchar(255) DEFAULT NULL,
  `accountLife` datetime DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `authMethod` varchar(255) DEFAULT NULL,
  `authToken` varchar(255) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `certificate` varchar(255) DEFAULT NULL,
  `certificateNo` varchar(255) DEFAULT NULL,
  `disabled` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `employeeNo` varchar(255) DEFAULT NULL,
  `fromUserId` varchar(255) DEFAULT NULL,
  `lastLogonTime` datetime DEFAULT NULL,
  `lastPwdChangeTime` datetime DEFAULT NULL,
  `lastPwdErrorTime` datetime DEFAULT NULL,
  `loginName` varchar(50) NOT NULL,
  `logonCount` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `passwordAnswer` varchar(255) DEFAULT NULL,
  `passwordQuestion` varchar(255) DEFAULT NULL,
  `passwordStrength` int(11) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `pwdErrorCount` int(11) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `loginName` (`loginName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_user`
--

LOCK TABLES `um_user` WRITE;
/*!40000 ALTER TABLE `um_user` DISABLE KEYS */;
INSERT INTO `um_user` VALUES (-10000,NULL,NULL,NULL,0,NULL,NULL,NULL,'2099-01-01 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,'ANONYMOUS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'匿名用户'),(-997,NULL,NULL,NULL,0,NULL,NULL,NULL,'2099-01-01 00:00:00',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,'Job.Robot',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'系统机器人'),(-1,NULL,NULL,NULL,0,NULL,NULL,NULL,'2099-01-01 00:00:00',NULL,'com.boubei.tss.um.sso.UMPasswordIdentifier',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,'Admin',NULL,'2C9AD05B31012DF7FCF60BFAC8DBD453',NULL,NULL,3,NULL,NULL,NULL,NULL,'系统管理员');
/*!40000 ALTER TABLE `um_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `um_user_token`
--

DROP TABLE IF EXISTS `um_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `um_user_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `expireTime` datetime DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `resource` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `um_user_token`
--

LOCK TABLES `um_user_token` WRITE;
/*!40000 ALTER TABLE `um_user_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `um_user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `view_channel_resource`
--

DROP TABLE IF EXISTS `view_channel_resource`;
/*!50001 DROP VIEW IF EXISTS `view_channel_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_channel_resource` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_group_resource`
--

DROP TABLE IF EXISTS `view_group_resource`;
/*!50001 DROP VIEW IF EXISTS `view_group_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_group_resource` (
  `ID` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_navigator_resource`
--

DROP TABLE IF EXISTS `view_navigator_resource`;
/*!50001 DROP VIEW IF EXISTS `view_navigator_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_navigator_resource` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_portal_resource`
--

DROP TABLE IF EXISTS `view_portal_resource`;
/*!50001 DROP VIEW IF EXISTS `view_portal_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_portal_resource` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_record_resource`
--

DROP TABLE IF EXISTS `view_record_resource`;
/*!50001 DROP VIEW IF EXISTS `view_record_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_record_resource` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_report_resource`
--

DROP TABLE IF EXISTS `view_report_resource`;
/*!50001 DROP VIEW IF EXISTS `view_report_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_report_resource` (
  `id` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_role_resource`
--

DROP TABLE IF EXISTS `view_role_resource`;
/*!50001 DROP VIEW IF EXISTS `view_role_resource`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_role_resource` (
  `ID` tinyint NOT NULL,
  `parentId` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `decode` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_roleuser`
--

DROP TABLE IF EXISTS `view_roleuser`;
/*!50001 DROP VIEW IF EXISTS `view_roleuser`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_roleuser` (
  `userId` tinyint NOT NULL,
  `roleId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_roleuser4subauthorize`
--

DROP TABLE IF EXISTS `view_roleuser4subauthorize`;
/*!50001 DROP VIEW IF EXISTS `view_roleuser4subauthorize`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_roleuser4subauthorize` (
  `userId` tinyint NOT NULL,
  `roleId` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `wf_log`
--

DROP TABLE IF EXISTS `wf_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wf_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `curstep` varchar(255) DEFAULT NULL,
  `itemId` bigint(20) NOT NULL,
  `nextStep` varchar(255) DEFAULT NULL,
  `nextStepProcesser` varchar(255) DEFAULT NULL,
  `processResult` longtext,
  `processer` varchar(255) NOT NULL,
  `processerTime1` datetime NOT NULL,
  `processerTime2` datetime NOT NULL,
  `tableId` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wf_log`
--

LOCK TABLES `wf_log` WRITE;
/*!40000 ALTER TABLE `wf_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `wf_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_feedback`
--

DROP TABLE IF EXISTS `x_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_feedback` (
  `module` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `content` varchar(1530) NOT NULL,
  `pic` varchar(100) DEFAULT NULL,
  `env` varchar(255) DEFAULT NULL,
  `udf1` varchar(255) DEFAULT NULL,
  `commiter` varchar(255) DEFAULT NULL,
  `state` varchar(255) NOT NULL,
  `processing` varchar(765) DEFAULT NULL,
  `processor` varchar(255) DEFAULT NULL,
  `remark` varchar(2040) DEFAULT NULL,
  `domain` varchar(50) DEFAULT NULL,
  `createtime` timestamp NULL DEFAULT NULL,
  `creator` varchar(50) NOT NULL,
  `updatetime` timestamp NULL DEFAULT NULL,
  `updator` varchar(50) DEFAULT NULL,
  `version` int(5) DEFAULT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `idx_x_feedback_module` (`module`),
  KEY `idx_x_feedback_commiter` (`commiter`),
  KEY `idx_x_feedback_processor` (`processor`),
  KEY `idx_x_feedback_domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_feedback`
--

LOCK TABLES `x_feedback` WRITE;
/*!40000 ALTER TABLE `x_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `x_serialno`
--

DROP TABLE IF EXISTS `x_serialno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `x_serialno` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createTime` datetime DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  `updateTime` datetime DEFAULT NULL,
  `updator` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `day` datetime NOT NULL,
  `lastNum` int(11) NOT NULL,
  `precode` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `x_serialno`
--

LOCK TABLES `x_serialno` WRITE;
/*!40000 ALTER TABLE `x_serialno` DISABLE KEYS */;
/*!40000 ALTER TABLE `x_serialno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `view_channel_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_channel_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_channel_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_channel_resource` AS select -(1) AS `id`,'全部' AS `name`,0 AS `parentId`,'00001' AS `decode` union select `cms_channel`.`id` AS `id`,`cms_channel`.`name` AS `name`,`cms_channel`.`parentId` AS `parentId`,`cms_channel`.`decode` AS `decode` from `cms_channel` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_group_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_group_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_group_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_group_resource` AS select `um_group`.`id` AS `ID`,`um_group`.`parentId` AS `parentId`,`um_group`.`name` AS `name`,`um_group`.`decode` AS `decode` from `um_group` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_navigator_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_navigator_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_navigator_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_navigator_resource` AS select 0 AS `id`,'root' AS `name`,-(1) AS `parentId`,'00001' AS `decode` union select `portal_navigator`.`id` AS `id`,`portal_navigator`.`name` AS `name`,`portal_navigator`.`parentId` AS `parentid`,`portal_navigator`.`decode` AS `decode` from `portal_navigator` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_portal_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_portal_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_portal_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_portal_resource` AS select 0 AS `id`,'root' AS `name`,-(1) AS `parentId`,'00001' AS `decode` union select `portal_structure`.`id` AS `id`,`portal_structure`.`name` AS `name`,`portal_structure`.`parentId` AS `parentId`,`portal_structure`.`decode` AS `decode` from `portal_structure` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_record_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_record_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_record_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_record_resource` AS select 0 AS `id`,'root' AS `name`,-(1) AS `parentId`,'00001' AS `decode` union select `dm_record`.`id` AS `id`,`dm_record`.`name` AS `name`,`dm_record`.`parentId` AS `parentId`,`dm_record`.`decode` AS `decode` from `dm_record` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_report_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_report_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_report_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_report_resource` AS select 0 AS `id`,'root' AS `name`,-(1) AS `parentId`,'00001' AS `decode` union select `dm_report`.`id` AS `id`,`dm_report`.`name` AS `name`,`dm_report`.`parentId` AS `parentId`,`dm_report`.`decode` AS `decode` from `dm_report` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_role_resource`
--

/*!50001 DROP TABLE IF EXISTS `view_role_resource`*/;
/*!50001 DROP VIEW IF EXISTS `view_role_resource`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_role_resource` AS select `um_role`.`id` AS `ID`,`um_role`.`parentId` AS `parentId`,`um_role`.`name` AS `name`,`um_role`.`decode` AS `decode` from `um_role` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_roleuser`
--

/*!50001 DROP TABLE IF EXISTS `view_roleuser`*/;
/*!50001 DROP VIEW IF EXISTS `view_roleuser`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_roleuser` AS select `u`.`id` AS `userId`,`r`.`id` AS `roleId` from ((`um_role` `r` join `um_roleuser` `ru`) join `um_user` `u`) where ((`r`.`id` = `ru`.`roleId`) and (`ru`.`userId` = `u`.`id`) and (`u`.`disabled` <> 1) and (`r`.`disabled` <> 1) and (sysdate() between `r`.`startDate` and `r`.`endDate`) and isnull(`ru`.`strategyId`)) union all select `u`.`id` AS `userId`,`r`.`id` AS `roleId` from (((`um_role` `r` join `um_roleuser` `ru`) join `um_user` `u`) join `um_sub_authorize` `s`) where ((`r`.`id` = `ru`.`roleId`) and (`ru`.`userId` = `u`.`id`) and (`u`.`disabled` <> 1) and (`r`.`disabled` <> 1) and (sysdate() between `r`.`startDate` and `r`.`endDate`) and (`s`.`id` = `ru`.`strategyId`) and (sysdate() between `s`.`startDate` and `s`.`endDate`) and (`s`.`disabled` <> 1)) union all select `u`.`id` AS `userId`,`r`.`id` AS `roleId` from ((((`um_group` `g` join `um_rolegroup` `rg`) join `um_role` `r`) join `um_groupuser` `gu`) join `um_user` `u`) where ((`g`.`id` = `rg`.`groupId`) and (`rg`.`roleId` = `r`.`id`) and (`g`.`id` = `gu`.`groupId`) and (`gu`.`userId` = `u`.`id`) and (`u`.`disabled` <> 1) and (`r`.`disabled` <> 1) and (`g`.`disabled` <> 1) and (sysdate() between `r`.`startDate` and `r`.`endDate`) and isnull(`rg`.`strategyId`)) union all select `u`.`id` AS `userId`,`r`.`id` AS `roleId` from (((((`um_group` `g` join `um_rolegroup` `rg`) join `um_role` `r`) join `um_groupuser` `gu`) join `um_user` `u`) join `um_sub_authorize` `s`) where ((`g`.`id` = `rg`.`groupId`) and (`rg`.`roleId` = `r`.`id`) and (`g`.`id` = `gu`.`groupId`) and (`gu`.`userId` = `u`.`id`) and (`u`.`disabled` <> 1) and (`r`.`disabled` <> 1) and (`g`.`disabled` <> 1) and (sysdate() between `r`.`startDate` and `r`.`endDate`) and (`s`.`id` = `rg`.`strategyId`) and (sysdate() between `s`.`startDate` and `s`.`endDate`) and (`s`.`disabled` <> 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_roleuser4subauthorize`
--

/*!50001 DROP TABLE IF EXISTS `view_roleuser4subauthorize`*/;
/*!50001 DROP VIEW IF EXISTS `view_roleuser4subauthorize`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_roleuser4subauthorize` AS select `u`.`id` AS `userId`,`r`.`id` AS `roleId` from ((`um_role` `r` join `um_roleuser` `ru`) join `um_user` `u`) where ((`r`.`id` = `ru`.`roleId`) and (`ru`.`userId` = `u`.`id`) and (`u`.`disabled` <> 1) and (`r`.`disabled` <> 1) and (sysdate() between `r`.`startDate` and `r`.`endDate`) and isnull(`ru`.`strategyId`)) union all select `u`.`id` AS `userId`,`r`.`id` AS `roleId` from ((((`um_group` `g` join `um_rolegroup` `rg`) join `um_role` `r`) join `um_groupuser` `gu`) join `um_user` `u`) where ((`g`.`id` = `rg`.`groupId`) and (`rg`.`roleId` = `r`.`id`) and (`g`.`id` = `gu`.`groupId`) and (`gu`.`userId` = `u`.`id`) and (`u`.`disabled` <> 1) and (`r`.`disabled` <> 1) and (`g`.`disabled` <> 1) and (sysdate() between `r`.`startDate` and `r`.`endDate`) and isnull(`rg`.`strategyId`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-21 15:50:04
